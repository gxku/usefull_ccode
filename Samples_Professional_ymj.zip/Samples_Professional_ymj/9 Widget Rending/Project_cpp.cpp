#define MAX_SCREEN_HEIGHT 1000
#define MAX_SCREEN_WIDTH  1000

#define BORDER            '+'
#define SPACE             ' '

enum TYPE {
	VWIDGET = 0,
	HWIDGET,
	TEXT,
	IMAGE,
};

typedef struct {
	int type;
	union {
		struct { int width; } vwidget;
		struct { int height; } hwidget;
		struct { char* strPtr; } text;
		struct { int height, width; char* imagePtr; } image;
	};
} Element;

typedef struct EEE{
	int type;
	union {
		struct { int width; } vwidget;
		struct { int height; } hwidget;
		struct { char* strPtr; } text;
		struct { int height, width; char* imagePtr; } image;
	};
	int text_len, wid, heit;
	int o_heit, o_wid;
	struct EEE * parent;
	int ch_cnt;
	int child[100];
} myElement;

char str[100][3000];
char img[100][50 * 50];
myElement elements[100];

int g_index;


void calculate(int elementId){
	int max_x = 0, max_y = 0;
	int i = 0;
	elements[elementId].heit = elements[elementId].o_heit;
	elements[elementId].wid = elements[elementId].o_wid;
	if (elements[elementId].type == VWIDGET){
		for (i = 0; i < elements[elementId].ch_cnt; i++){
			int ch_id = elements[elementId].child[i];
			if (elements[ch_id].type != TEXT){
				calculate(ch_id);
				elements[elementId].wid = elements[elementId].wid >(elements[ch_id].wid + 2) ? elements[elementId].wid : (elements[ch_id].wid + 2);
				elements[elementId].heit += elements[ch_id].heit;
			}
		}

		for (i = 0; i < elements[elementId].ch_cnt; i++){
			int ch_id = elements[elementId].child[i];
			if (elements[ch_id].type == TEXT){
				calculate(ch_id);
				elements[elementId].heit += elements[ch_id].heit;
			}
		}

	}
	else if (elements[elementId].type == HWIDGET){
		for (i = 0; i < elements[elementId].ch_cnt; i++){
			int ch_id = elements[elementId].child[i];
			if (elements[ch_id].type != TEXT){
				calculate(ch_id);
				elements[elementId].wid += elements[ch_id].wid;
				elements[elementId].heit = elements[elementId].heit >(elements[ch_id].heit + 2) ? elements[elementId].heit : (elements[ch_id].heit + 2);
			}
		}

		for (i = 0; i < elements[elementId].ch_cnt; i++){
			int ch_id = elements[elementId].child[i];
			if (elements[ch_id].type == TEXT){
				calculate(ch_id);
				elements[elementId].wid += elements[ch_id].wid;
			}
		}

	}
	else if (elements[elementId].type == IMAGE){

	}
	else if (elements[elementId].type == TEXT){
		int k = 0;
		int len = 0;
		int p_len = 0;
		if (elements[elementId].parent->type == VWIDGET){
			len = elements[elementId].text_len;
			p_len = elements[elementId].parent->wid - 2;
			elements[elementId].heit = len / p_len + (len%p_len == 0 ? 0 : 1);
			elements[elementId].wid = p_len;
		}
		else{
			len = elements[elementId].text_len;
			p_len = elements[elementId].parent->heit - 2;
			elements[elementId].wid = len / p_len + (len%p_len == 0 ? 0 : 1);
			elements[elementId].heit = p_len;
		}
	}

}
void do_show(int elementId, int x, int y, char screen[MAX_SCREEN_HEIGHT][MAX_SCREEN_WIDTH]){
	int i, j;
	int k = 0;
	if (elements[elementId].type == VWIDGET){
		for (i = y; i < elements[elementId].heit + y; i++){
			for (j = x; j < elements[elementId].wid + x; j++){
				if (i == y || j == x || i == elements[elementId].heit + y - 1 || j == elements[elementId].wid + x - 1){
					screen[i][j] = BORDER;
				}
				else{
					screen[i][j] = SPACE;
				}
			}
		}
		x = x + 1;
		y = y + 1;
		for (i = 0; i < elements[elementId].ch_cnt; i++){

			do_show(elements[elementId].child[i], x, y, screen);
			y = y + elements[elements[elementId].child[i]].heit;
		}
	}

	if (elements[elementId].type == HWIDGET){
		for (i = y; i < elements[elementId].heit + y; i++){
			for (j = x; j < elements[elementId].wid + x; j++){
				if (i == y || j == x || i == elements[elementId].heit + y - 1 || j == elements[elementId].wid + x - 1){
					screen[i][j] = BORDER;
				}
				else{
					screen[i][j] = SPACE;
				}
			}
		}
		x = x + 1;
		y = y + 1;
		for (i = 0; i < elements[elementId].ch_cnt; i++){

			do_show(elements[elementId].child[i], x, y, screen);
			x = x + elements[elements[elementId].child[i]].wid;
		}
	}
	if (elements[elementId].type == IMAGE){

		for (i = y; i < elements[elementId].heit + y; i++){
			for (j = x; j < elements[elementId].wid + x; j++){

				screen[i][j] = img[elementId][k++];

			}
		}
	}
	if (elements[elementId].type == TEXT){

		if (elements[elementId].parent->type == VWIDGET){
			for (i = y; i < elements[elementId].heit + y; i++){
				for (j = x; j < elements[elementId].wid + x; j++){

					screen[i][j] = str[elementId][k++];
					if (elements[elementId].text_len == k)return;

				}
			}
		}
		else{
			for (j = x; j < elements[elementId].wid + x; j++){
				for (i = y; i < elements[elementId].heit + y; i++){

					screen[i][j] = str[elementId][k++];
					if (elements[elementId].text_len == k)return;
				}
			}
		}
	}


}

///////////////////////////////////////////////////////
void init() {
	g_index = 0;
}

int create(Element* elemet) {
	char *p;
	int i = 0;
	switch (elemet->type)
	{
	case VWIDGET:
		elements[g_index].type = elemet->type;
		elements[g_index].vwidget.width = elemet->vwidget.width;
		elements[g_index].o_wid = elemet->vwidget.width;
		elements[g_index].o_heit = 2;
		break;
	case	HWIDGET:
		elements[g_index].type = elemet->type;
		elements[g_index].hwidget.height = elemet->hwidget.height;
		elements[g_index].o_wid = 2;
		elements[g_index].o_heit = elemet->hwidget.height;
		break;
	case	TEXT:
		elements[g_index].type = elemet->type;
		p = elemet->text.strPtr;
		i = 0;
		while (*p != '\0')
		{
			str[g_index][i] = *p;
			i++;
			p++;
		}
		elements[g_index].text.strPtr = str[g_index];
		elements[g_index].text_len = i;
		break;
	case	IMAGE:
		elements[g_index].type = elemet->type;
		p = elemet->image.imagePtr;
		for (i = 0; i < elemet->image.width*elemet->image.height; i++){
			img[g_index][i] = p[i];
		}
		elements[g_index].image.imagePtr = img[g_index];
		elements[g_index].o_wid = elemet->image.width;
		elements[g_index].o_heit = elemet->image.height;
		break;
	default:
		return -1;
		break;
	}
	elements[g_index].ch_cnt = 0;
	//g_index++;
	return g_index++;  // return id
}

void add(int parentId, int childId) {
	elements[childId].parent = &elements[parentId];
	int n = elements[parentId].ch_cnt;
	elements[parentId].child[n] = childId;
	elements[parentId].ch_cnt++;

}

void show(int elementId, char screen[MAX_SCREEN_HEIGHT][MAX_SCREEN_WIDTH]) {
	calculate(elementId);
	do_show(elementId, 0, 0, screen);
}