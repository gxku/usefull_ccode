class UserSolution {
    public final static int MAX_SCREEN_HEIGHT = 1000;
    public final static int MAX_SCREEN_WIDTH  = 1000;
    
    public final static int VWIDGET           = 0;
    public final static int HWIDGET           = 1;
    public final static int TEXT              = 2;
    public final static int IMAGE             = 3;
    
    public final static byte BORDER           = '+';
    public final static byte SPACE            = ' ';
    

    
    public void init() 
    {
    	
    	
    	
    }
    
    public int create(Solution.Element element) 
    {
    	
		return -1;
    }
    


	public void add(int parentId, int childId) 
	{
			
		
        
    }
    
    public void show(int elementId, char[][] screen) 
    {
    	
    }
    
    
    	
}