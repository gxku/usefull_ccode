import java.util.Scanner;

public class Solution {
	private static Scanner sc;

	private final static int MAX_ACCOUNT = 50000;
	private final static int MAX_TIME = 30000;
	private final static int MAX_STR = 11;
	
	private final static int INIT = 0;
	private final static int NEWACCOUNT = 1;
	private final static int LOGOUT = 2;
	private final static int CONNECT = 3;
	private final static int TICK = 4;
	
	private static class ACCOUNT {
        public char id[];
		public char password[];
		public int defaulttime;
		
		ACCOUNT() {
			id = new char[MAX_STR];
			password = new char[MAX_STR];
		}
    }
	
	private static UserSolution user = new UserSolution();
	private static ACCOUNT account[] = new ACCOUNT[MAX_ACCOUNT];
	
	private static int mSeed;
	private static int mrand(int num)
	{
		mSeed = mSeed * 1103515245 + 12345;
		return (((mSeed >> 16) & 0x00007FFF) % num);
	}
	
	static {
		for (int i = 0; i < MAX_ACCOUNT; i++)
			account[i] = new ACCOUNT();
	}
	
	static void make_account(int cnt)
	{
		for (int i = 0; i < cnt; i++) {
			int idl = 5 + mrand(6);
			for (int k = 0; k < idl; k++) {
				int ch = mrand(36);
				if (ch < 10) account[i].id[k] = (char)(ch + '0');
				else account[i].id[k] = (char)(ch - 10 + 'a');
			}
			account[i].id[idl] = '\0';

			int pal = 5 + mrand(6);
			for (int k = 0; k < pal; k++) {
				int ch = mrand(36);
				if (ch < 10) account[i].password[k] = (char)(ch + '0');
				else account[i].password[k] = (char)(ch - 10 + 'a');
			}
			account[i].password[pal] = '\0';

			int max_time = cnt;
			if (max_time > MAX_TIME) max_time = MAX_TIME;
			account[i].defaulttime = 1 + mrand(max_time);
		}
	}
	
	static void init(int num)
	{
		user.Init();

		make_account(num);
		for (int i = 0; i < num / 3; i++) {
			user.NewAccount(account[i].id, account[i].password, account[i].defaulttime);
		}
	}

	static int run()
	{
		int ret = 1;
		int cmd, num, cmdcnt, param1, param2;

		cmd = sc.nextInt();
		mSeed = sc.nextInt();
		num = sc.nextInt();
		cmdcnt = sc.nextInt();

		init(num);

		for (int i = 0; i < cmdcnt; i++) {
			cmd = sc.nextInt();
			if (cmd == NEWACCOUNT) {
				param1 = sc.nextInt();
				param2 = sc.nextInt();				
				user.NewAccount(account[param1].id, account[param1].password, param2);
			}
			else if (cmd == LOGOUT) {
				param1 = sc.nextInt();				
				user.Logout(account[param1].id);
			}
			else if (cmd == CONNECT) {
				param1 = sc.nextInt();
				param2 = sc.nextInt();
				user.Connect(account[param1].id, account[param2].password);
			}
			else if (cmd == TICK) {
				param1 = sc.nextInt();
				int result = user.Tick();
				if (result != param1)
					ret = 0;
			}
		}

		return ret;
	}	

	public static void main(String[] args) throws Exception {
		// System.setIn(new java.io.FileInputStream("sample_input.txt"));
		sc = new Scanner(System.in);		
				
		int T;
		T = sc.nextInt();
		for (int tc = 1; tc <= T; ++tc) {
			int Score = 100;
			if (run() == 0)
				Score = 0;
			System.out.println("#" + tc + " " + Score);
		}
		sc.close();
	}
}