#define MAX_ACCOUNT 50000
#define MAX_TIME 30000

#define HASH_M 131313

typedef struct list
{
	struct list *prev, *next;
}NODE;

typedef struct {
	struct list  hash_list;
	struct list  time_list;

	char id[11];
	int id_hash;
	char password[11];
	int defaulttime;
	int time;
	int login;
}USR;

USR users[MAX_ACCOUNT];
int g_index;
int g_cur = 0;
struct list hash_table[HASH_M];
int hash_table_num[HASH_M];
struct list time_ring[MAX_TIME];
/////////////////////////////////////////
void list_init(NODE *head){
	head->next = head->prev = head;
}

void _list_add(NODE * now,NODE *prev,NODE *next){
	now->next = next;
	now->prev = prev;
	prev->next = now;
	next->prev = now;
}

void list_add(NODE *head,NODE *now){
	_list_add(now,head,head->next);
}

void list_add_tail(NODE *head, NODE *now){
	_list_add(now, head->prev, head);
}

void list_del(NODE *now){
	now->next->prev = now->prev;
	now->prev->next = now->next;
	now->next = now->prev = now;//
}

#define hash_to_user(hash_node) (USR*)(hash_node)
#define time_to_user(time_node) (USR*)((char*)time_node-(unsigned long)(&((USR*)0)->time_list)) 
//////////////////////////////////////////
void str_cp(char *from,char* to){
	while (*from!='\0'){
		*to = *from;
		from++;
		to++;
	}
	*to = *from;
}

int  str_eq(char *a, char* b){
	while (*a != '\0'&&*b != '\0'&&*a == *b){
		a++;
		b++;
	}
	if (*a == '\0'&&*b == '\0'){
		return 0;
	}
	else {
		return *a-*b;
	}
}

int check_pwd(char *a, char* b){
	return str_eq(a, b);
}

int hash(char *str){
	int h = 0;
	int seed = 1313;
	while (*str != '\0'){
		h = (h*seed + *str)%HASH_M;
		str++;
	}
	return h;
}

void time_list_add(NODE *node, int time){
	int real_time = (g_cur + time)% MAX_TIME;
	list_add(&time_ring[real_time], node);
}

USR * get_usr(char id[11]){
	int id_hash = hash(id);
	if (hash_table_num[id_hash] == 1){
		return hash_to_user(hash_table[id_hash].next);
	}
	else if(hash_table_num[id_hash] >1) {
		struct list *node = hash_table[id_hash].next;
		USR* usr;
		for (int i = 0; i < hash_table_num[id_hash]; i++){
			usr = hash_to_user(node);
			if (str_eq(usr->id,id) == 0)return usr;
			node = node->next;
		}
	}

	return 0;//err
}
//////////////////////////////////////////
void Init()
{
	for (int i = 0; i < HASH_M; i++){
		list_init(&hash_table[i]);
		hash_table_num[i] = 0;
	}
	for (int i = 0; i < MAX_TIME; i++){
		list_init(&time_ring[i]);
	}
	g_index = 0;
}
void NewAccount(char id[11], char password[11], int defaulttime)
{
	int index = g_index++;
	int id_hash = hash(id);
	users[index].id_hash = id_hash;
	users[index].login = 1;
	str_cp(id,users[index].id);
	str_cp(password, users[index].password);
	users[index].defaulttime = defaulttime;
	
	list_add(&hash_table[id_hash], &users[index].hash_list);
	hash_table_num[id_hash]++;
	time_list_add(&users[index].time_list, users[index].defaulttime);

}
void Logout(char id[11])
{
	USR * usr = get_usr(id);
	usr->login = 0;
	list_del(&usr->time_list);
}

void Connect(char id[11], char password[11])
{
	USR * usr = get_usr(id);
	if (usr->login == 0)return;
	if (check_pwd(usr->password, password) == 0){
		list_del(&usr->time_list);
		time_list_add(&usr->time_list, usr->defaulttime);
	}

}
int Tick()
{
	int n = 0;
	g_cur++;
	g_cur = g_cur%MAX_TIME;
	NODE* root = &time_ring[g_cur];
	NODE* node=root->next;
	USR* usr = 0;
	while (node !=  root){
		usr = time_to_user(node);
		usr->login = 0;
		list_del(node);
		node = root->next;
		n++;
	}
	return n;
}