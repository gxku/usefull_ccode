public class UserSolution {
	
	public void Init()
	{
	}

	public void NewAccount(char id[], char password[], int defaulttime)
	{
	}

	public void Logout(char id[])
	{
	}

	public void Connect(char id[], char password[])
	{
	}

	public int Tick()
	{
		return 0;
	}	
}