class UserSolution {
	private final static int STRINGTYPE = 0x01;
	private final static int SETTYPE    = 0x02;
	
	private final static int MAX_KEY_LENGTH     = 15;
	private final static int MAX_VALUE_LENGTH   = 127;
	private final static int MAX_MESSAGE_LENGTH = 81920;

	////the below functions are provided for your convenience
	//private final static char hex[] = new char[]{
	//	'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'
	//};
	
	//private void printHex(char message[], int length) {
	//	for (int i = 0; i < length; i += 16) {
	//		for (int j = 0; j < 16 && i + j < length; ++j)
	//			System.out.print(new String(new char[]{hex[message[i + j] >> 4], hex[message[i + j] & 0x0f], ' '}));
	//		System.out.println();
	//	}
	//}
	
	//private void ztrncpy(char dest[], char src[], int offset, int length) {
	//	int pos = 0;
	//	while(pos < length && src[pos + offset] != '\0') {
	//		dest[pos] = src[pos + offset];
	//		++pos;
	//	}
	//	dest[pos] = '\0';
	//}
	
	//private int ztrlen(char str[]) {
	//	int pos = 0;
	//	while(str[pos] != '\0')
	// 		++pos;
	//	return pos;
	//}
	
    public void parse(char in[], int size) {

    }
    
    public void set(char targetkey[], char newvalue[]) {

	}
	
	public void add(char parentkey[], char childkey[], char childvalue[]) {
	
	}
	
	public void erase(char targetkey[]) {
		
	}
	
	public int generate(char targetkey[], char out[]) {
		return 0; // return the size of the encoded IoT Message wich is stored in the array of out.
	}
}