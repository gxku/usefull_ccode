#define STRINGTYPE         0x01
#define SETTYPE            0x02

#define MAX_KEY_LENGTH     15
#define MAX_VALUE_LENGTH   127
#define MAX_MESSAGE_LENGTH 81920


struct NODE{
	int type;
	int M;
	char key[16];
	int hash_key;
	int N;
	int val_ent[128];

	int parent;
	int total_len;

}nodes[420];

int g_index;
int g_root;

int  do_parse(char in[MAX_MESSAGE_LENGTH], int size, int pid){
	int i;
	int index = g_index++;
	nodes[index].type = in[0];
	nodes[index].M = in[1] * 128 + in[2];
	nodes[index].parent = pid;
	nodes[index].hash_key = 0;
	for (i = 0; i < nodes[index].M; i++){
		nodes[index].key[i] = in[3 + i];
		nodes[index].hash_key += in[3 + i];
	}
	nodes[index].key[i] = '\0';
	nodes[index].N = in[3 + i] * 128 + in[4 + i];

	if (nodes[index].type == STRINGTYPE){
		for (i = 0; i < nodes[index].N; i++){
			nodes[index].val_ent[i] = in[5 + nodes[index].M + i];
		}
		nodes[index].val_ent[i] = '\0';
		nodes[index].total_len = 5 + nodes[index].M + nodes[index].N;
	}
	else{
		int start = 5 + nodes[index].M;
		int len = size - start;
		int id = 0;

		nodes[index].total_len = 5 + nodes[index].M;
		for (i = 0; i < nodes[index].N; i++){

			id = do_parse(&in[start], len, index);
			nodes[index].val_ent[i] = id;
			start += nodes[id].total_len;
			len -= nodes[id].total_len;
			nodes[index].total_len += nodes[id].total_len;
		}

	}
	return index;
}

int get_len(char str[MAX_KEY_LENGTH + 1]){
	int i = 0;
	while (str[i] != '\0'){
		i++;
	}
	return i;
}

int hash(char str[MAX_KEY_LENGTH + 1]){
	int i = 0;
	int sum = 0;
	while (str[i] != '\0'){
		sum += str[i];
		i++;
	}
	return sum;
}
int str_eq(char str1[MAX_KEY_LENGTH + 1], char str2[MAX_KEY_LENGTH + 1]){
	int i = 0;
	int ret = 0;
	while (str1[i] != '\0'&&str2[i] != '\0'&&str1[i] == str2[i]){
		i++;
	}
	if (str1[i] == '\0'&&str2[i] == '\0'){
		ret = 1;
	}
	return ret;
}

int get_id(char targetkey[MAX_KEY_LENGTH + 1]){
	int len = get_len(targetkey);
	int hash_sum = hash(targetkey);

	for (int i = 0; i < g_index; i++){
		if (hash_sum == nodes[i].hash_key && len == nodes[i].M){
			if (str_eq(targetkey, nodes[i].key))return i;
		}
	}
	return -1;
}


void  do_generate(int node_id, char out[MAX_MESSAGE_LENGTH]){
	int i;
	int id = node_id;
	int n_id;
	out[0] = nodes[id].type;
	out[1] = nodes[id].M / 128;
	out[2] = nodes[id].M % 128;

	for (i = 0; i < nodes[id].M; i++){
		out[3 + i] = nodes[id].key[i];
	}
	out[3 + i] = nodes[id].N / 128;
	out[4 + i] = nodes[id].N % 128;

	if (nodes[id].type == STRINGTYPE){
		for (i = 0; i < nodes[id].N; i++){
			out[5 + nodes[id].M + i] = nodes[id].val_ent[i];
		}
	}
	else{
		int start = 5 + nodes[id].M;

		for (i = 0; i < nodes[id].N; i++){
			n_id = nodes[id].val_ent[i];
			do_generate(n_id, &out[start]);

			start += nodes[n_id].total_len;
		}
	}

}
////////////////////////////////////////////////////
void parse(char in[MAX_MESSAGE_LENGTH], int size) {
	g_index = 0;

	g_root = do_parse(in, size, -1);
}

void set(char targetkey[MAX_KEY_LENGTH + 1], char newvalue[MAX_VALUE_LENGTH + 1]) {
	int i = 0;
	int id = get_id(targetkey);
	int D_len;
	//if (id == -1){ while (1); }
	char *p = newvalue;

	while (*p != '\0')
	{
		nodes[id].val_ent[i++] = *p++;
	}
	nodes[id].val_ent[i] = '\0';
	D_len = i - nodes[id].N;
	nodes[id].N = i;

	//////parent
	int pid = id;
	while (pid != -1)
	{
		nodes[pid].total_len += D_len;
		pid = nodes[pid].parent;
	}
}

void add(char parentkey[MAX_KEY_LENGTH + 1], char childkey[MAX_KEY_LENGTH + 1], char childvalue[MAX_VALUE_LENGTH + 1]) {
	int i;
	int pid = get_id(parentkey);
	int index = g_index++;
	nodes[index].type = STRINGTYPE;
	nodes[index].parent = pid;

	nodes[index].hash_key = 0;
	char *p = childkey;
	i = 0;
	while (*p != '\0')
	{

		nodes[index].key[i] = *p;
		nodes[index].hash_key += *p;
		i++;
		p++;
	}
	nodes[index].key[i] = '\0';
	nodes[index].M = i;
	/////////////////////value
	p = childvalue;
	i = 0;
	while (*p != '\0')
	{

		nodes[index].val_ent[i] = *p;
		i++;
		p++;
	}
	nodes[index].val_ent[i] = '\0';
	nodes[index].N = i;
	nodes[index].total_len = 5 + nodes[index].M + nodes[index].N;
	///////parent
	nodes[pid].val_ent[nodes[pid].N++] = index;
	while (pid != -1)
	{
		nodes[pid].total_len += nodes[index].total_len;
		pid = nodes[pid].parent;
	}
}

void erase(char targetkey[MAX_KEY_LENGTH + 1]) {
	int id = get_id(targetkey);
	int pid = nodes[id].parent;
	int tmp;
	for (int i = 0; i < nodes[pid].N; i++){
		if (nodes[pid].val_ent[i] == id){
			tmp = nodes[pid].val_ent[i];
			nodes[pid].val_ent[i] = nodes[pid].val_ent[i + 1];
			nodes[pid].val_ent[i + 1] = tmp;
		}
	}

	nodes[pid].N--;
	while (pid != -1)
	{
		nodes[pid].total_len -= nodes[id].total_len;

		pid = nodes[pid].parent;
	}
}

int generate(char targetkey[MAX_KEY_LENGTH + 1], char out[MAX_MESSAGE_LENGTH]) {

	int id = get_id(targetkey);
	do_generate(id, out);
	return nodes[id].total_len;   // return the size of the encoded IoT Message which is stored in the array of out. 
}

