import java.util.Scanner;

class Solution {
    private final static int PARSE              = 100;
	private final static int SET                = 200;
	private final static int ADD                = 300;
	private final static int ERASE              = 400;
	private final static int GENERATE           = 500;
	
	private final static int THRESHOLD          = 0x07FFFFFF;
	
	private final static int MAX_KEY_LENGTH     = 15;
	private final static int MAX_VALUE_LENGTH   = 127;
	private final static int MAX_MESSAGE_LENGTH = 81920;
	
	private final static char in[] = new char[MAX_MESSAGE_LENGTH];
	private final static char out[] = new char[MAX_MESSAGE_LENGTH];
	
	private static int expected;
	private static int point;
	
	private final static UserSolution usersolution = new UserSolution();
	
	private static int calcHash(char message[], int len) {
		int ret = 0;
		int count = 0;
		
		for (int i = 1; i < len; ++i) {
			ret += message[i] * count++;
			ret &= THRESHOLD;
		}
		
		return ret;
	}
	
	private static int get16(char c) {
		return c >= 'a' ? 10 + c - 'a' : c - '0';
	}
	
	private static void String2Char(char[] ch, String str) {
		int n = str.length();
		int p = 0;

		while(p < n) {
			ch[p] = str.charAt(p);
			++p;
		}
		ch[p] = '\0';
	}
	
	private static void run(Scanner sc) {
		int lineN;
		
		char targetkey[] = new char[MAX_KEY_LENGTH + 1];
		char newvalue[] = new char[MAX_VALUE_LENGTH + 1];
		char parentkey[] = new char[MAX_KEY_LENGTH + 1];
		char childkey[] = new char[MAX_KEY_LENGTH + 1];
		char childvalue[] = new char[MAX_VALUE_LENGTH + 1];
		
		String targetkeyStr, newvalueStr, parentkeyStr, childkeyStr, childvalueStr;
		int hash, length, resultlength, resulthash;
		point = 0;
		lineN = sc.nextInt();
		expected = sc.nextInt();
		
		for (int line = 0; line < lineN; ++line) {
			int command = sc.nextInt();
			switch(command) {
			case PARSE:
				int len = sc.nextInt();
				for (int p = 0; p < len;) {
					String buf = sc.next();
					for (int i = 0; i < 64 && p < len; i += 2, ++p)
						in[p] = (char) ((get16(buf.charAt(i)) << 4) | get16(buf.charAt(i + 1)));
				}
				usersolution.parse(in, len);
				break;
			case SET:
				targetkeyStr = sc.next();
				newvalueStr = sc.next();
				String2Char(targetkey, targetkeyStr);
				String2Char(newvalue, newvalueStr);
				usersolution.set(targetkey, newvalue);
				break;
			case ADD:
				parentkeyStr = sc.next();
				childkeyStr = sc.next();
				childvalueStr = sc.next();
				String2Char(parentkey, parentkeyStr);
				String2Char(childkey, childkeyStr);
				String2Char(childvalue, childvalueStr);
				usersolution.add(parentkey, childkey, childvalue);
				break;
			case ERASE:
				targetkeyStr = sc.next();
				String2Char(targetkey, targetkeyStr);
				usersolution.erase(targetkey);
				break;
			case GENERATE:
				targetkeyStr = sc.next();
				length = sc.nextInt();
				hash = sc.nextInt();
				String2Char(targetkey, targetkeyStr);
				resultlength = usersolution.generate(targetkey, out);
				if (length == resultlength) {
					resulthash = calcHash(out, length);
					if (resulthash == hash) point++;
				}
				break;
			}
		}
	}
	
	public static void main(String[] args) throws Exception {
		int T, total_score;
	
		//System.setIn(new java.io.FileInputStream("res/sample_input.txt"));
		Scanner sc = new Scanner(System.in);
		T = sc.nextInt();
        
        total_score = 0;
		for (int testcase = 1; testcase <= T; ++testcase) {
            run(sc);
            System.out.println("#" + testcase + " " + point);
			if (point == expected) total_score++;
		}

        System.out.println("total score = " + total_score * 100 / T);
		sc.close();
	}
}