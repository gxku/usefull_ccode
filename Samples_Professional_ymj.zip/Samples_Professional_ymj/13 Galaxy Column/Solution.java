class UserSolution {
    private static final int BLOCK_SIZE = 3;

    public void init(int width) {

    }

    public void newBlock(int block[]) {

    }

    public void specialBlock(int type) {

    }

    public void circulate(int count) {

    }

    public void move(int distance) {

    }

    public int land() {
        return -1;
    }
}