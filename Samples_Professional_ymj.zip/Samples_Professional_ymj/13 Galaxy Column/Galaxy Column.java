 import java.util.Scanner;

class Solution {
    private static final int BOARD_MAX_WIDTH = 10;
    private static final int BLOCK_SIZE = 3;
    private static final int SPECIAL_BLOCK = 9;
    private static final int CMD_CIRCULATE = 100;
    private static final int CMD_MOVE = 200;

    private static Scanner sc;
    private static UserSolution userSolution = new UserSolution();

    public static void main(String arg[]) throws Exception {
        // System.setIn(new java.io.FileInputStream("sample_input.txt"));
        sc = new Scanner(System.in);

        int testCnt;
        int totalScore = 0;
        int block[] = new int[BLOCK_SIZE];

        testCnt = sc.nextInt();
        for (int tc = 1; tc <= testCnt; ++tc) {
            int boardWidth = sc.nextInt();
            int blockCnt = sc.nextInt();
            int score = 100;

            userSolution.init(boardWidth);

            for (int i = 0; i < blockCnt; ++i) {
                block[0] = sc.nextInt();
                block[1] = sc.nextInt();
                block[2] = sc.nextInt();

                if (block[0] == SPECIAL_BLOCK) {
                    userSolution.specialBlock(block[2]);
                } 
                else {
                    userSolution.newBlock(block);
                }
                
                int cmdCnt, cmd, option;
                cmdCnt = sc.nextInt();
                for (int j = 0; j < cmdCnt; ++j) {
                    cmd = sc.nextInt();
                    option = sc.nextInt();

                    switch (cmd) {
                    case CMD_CIRCULATE:
                        userSolution.circulate(option);
                        break;
                    case CMD_MOVE:
                        userSolution.move(option);
                        break;
                    default:
                        System.out.println("cmd error");
                        break;
                    }
                }

                int answer = sc.nextInt();
                int result = userSolution.land();
                if (answer != result) {
                    score = 0; // wrong answer
                }
            }

            System.out.println("#" + tc + " " + score);
            totalScore += score;
        }

        System.out.println("Total Score : " + (totalScore / testCnt));
    }
}