
#define BOARD_MAX_WIDTH         10
#define BLOCK_SIZE          3
#define MAX_HIGHT            901


#define MODIFYED         1
#define CANRM            2


int game_bd_value[BOARD_MAX_WIDTH][MAX_HIGHT];
int game_bd_status[BOARD_MAX_WIDTH][MAX_HIGHT];

int game_bd_num[BOARD_MAX_WIDTH];
int g_width;
int g_mv = 0;
int blk[3];

struct NNN {
	int i;
	int j;
}queue[600];// , del_queue[600];
int g_queue_cnt;

/////////////////////////////////
int get_cricls(){
	int ret = 0;
	for (int j = 0; j < g_width; j++){
		ret+=game_bd_num[j];
	}
	return ret;
}
void in_queue_modify(int i, int j){
	int cnt = g_queue_cnt++;
	queue[cnt].i = i;
	queue[cnt].j = j;
	game_bd_status[i][j] = MODIFYED;
}

void should_del(int i, int j){
	game_bd_status[i][j] = CANRM;
}

void down_b(){
	int i = g_mv;
	int j = game_bd_num[i];
	if (blk[0]>=10){
		game_bd_value[i][j] = blk[0];
		game_bd_num[i]++;
		in_queue_modify(i,j);
	}
	else{
		for (int n = 0; n < 3; n++){
			game_bd_value[i][j] = blk[n];
			game_bd_status[i][j] = 0;
			game_bd_num[i]++;
			in_queue_modify(i, j++);
		}
	}
}

//-
void check1(int num, int i, int j){
	int go = 1;
	int v = game_bd_value[i][j];
	int n = 1;
	int m = i;
	int k = j;
	while (go)
	{
		m--;
		if (m >= 0){
			if (game_bd_value[m][k] == v){
				n++;
			}
			else{
				go = 0;
			}
		}
		else{
			go = 0;
		}
	}
	go = 1;
	m = i;
	while (go)
	{
		m++;
		if (m < g_width){
			if (game_bd_value[m][k] == v){
				n++;
			}
			else{
				go = 0;
			}
		}
		else{
			go = 0;
		}
	}

	if (n >= num){
		go = 1;
		m = i;
		should_del(m, k);
		while (go)
		{
			m--;
			if (m >= 0){
				if (game_bd_value[m][k] == v){
					should_del(m, k);
				}
				else{
					go = 0;
				}
			}
			else{
				go = 0;
			}
		}
		go = 1;
		m = i;
		while (go)
		{
			m++;
			if (m < g_width){
				if (game_bd_value[m][k] == v){
					should_del(m, k);
				}
				else{
					go = 0;
				}
			}
			else{
				go = 0;
			}
		}
	}
}
//|
void check2(int num, int i, int j){
	int go = 1;
	int v = game_bd_value[i][j];
	int n = 1;
	int k = j;
	int m = i;
	while (go)
	{
		k--;
		if (k >= 0){
			if (game_bd_value[m][k] == v){
				n++;
			}
			else{
				go = 0;
			}
		}
		else{
			go = 0;
		}
	}
	go = 1;
	k = j;
	while (go)
	{
		k++;
		if (k < game_bd_num[m]){
			if (game_bd_value[m][k] == v){
				n++;
			}
			else{
				go = 0;
			}
		}
		else{
			go = 0;
		}
	}

	if (n >= num){
		go = 1;
		k = j;
		should_del(m, k);
		while (go)
		{
			k--;
			if (k >= 0){
				if (game_bd_value[m][k] == v){
					should_del(m, k);
				}
				else{
					go = 0;
				}
			}
			else{
				go = 0;
			}
		}
		go = 1;
		k = j;
		while (go)
		{
			k++;
			if (k < game_bd_num[m]){
				if (game_bd_value[m][k] == v){
					should_del(m, k);
				}
				else{
					go = 0;
				}
			}
			else{
				go = 0;
			}
		}
	}
}
///
void check3(int num, int i, int j){
	int go = 1;
	int v = game_bd_value[i][j];
	int n = 1;
	int m = i;
	int k = j;
	while (go)
	{
		m--;
		k--;
		if (m >= 0&&k>=0){
			if (game_bd_value[m][k] == v){
				n++;
			}
			else{
				go = 0;
			}
		}
		else{
			go = 0;
		}
	}
	go = 1;
	m = i;
	k = j;
	while (go)
	{
		k++;
		m++;
		if (m<g_width &&k < game_bd_num[m]){
			if (game_bd_value[m][k] == v){
				n++;
			}
			else{
				go = 0;
			}
		}
		else{
			go = 0;
		}
	}

	if (n >= num){
		go = 1;
		m = i;
		k = j;
		should_del(m, k);
		while (go)
		{
			m--;
			k--;
			if (m >= 0 && k >= 0){
				if (game_bd_value[m][k] == v){
					should_del(m, k);
				}
				else{
					go = 0;
				}
			}
			else{
				go = 0;
			}
		}
		go = 1;
		m = i;
		k = j;
		while (go)
		{
			k++;
			m++;
			if (m<g_width &&k < game_bd_num[m]){
				if (game_bd_value[m][k] == v){
					should_del(m, k);
				}
				else{
					go = 0;
				}
			}
			else{
				go = 0;
			}
		}
	}
}
//\//
void check4(int num, int i, int j){
	int go = 1;
	int v = game_bd_value[i][j];
	int n = 1;
	int m = i;
	int k = j;
	while (go)
	{
		m++;
		k--;
		if (m<g_width&& k >= 0){
			if (game_bd_value[m][k] == v){
				n++;
			}
			else{
				go = 0;
			}
		}
		else{
			go = 0;
		}
	}
	go = 1;
	m = i;
	k = j;
	while (go)
	{
		m--; 
		k++;
		if (m >= 0 && k < game_bd_num[m]){
			if (game_bd_value[m][k] == v){
				n++;
			}
			else{
				go = 0;
			}
		}
		else{
			go = 0;
		}
	}

	if (n >= num){
		go = 1;
		m = i;
		k = j;
		should_del(m, k);
		while (go)
		{
			m++;
			k--;
			if (m<g_width&& k >= 0){
				if (game_bd_value[m][k] == v){
					should_del(m, k);
				}
				else{
					go = 0;
				}
			}
			else{
				go = 0;
			}
		}
		go = 1;
		m = i;
		k = j;
		while (go)
		{
			m--;
			k++;
			if (m >= 0 && k < game_bd_num[m]){
				if (game_bd_value[m][k] == v){
					should_del(m, k);
				}
				else{
					go = 0;
				}
			}
			else{
				go = 0;
			}
		}
	}
}


void check(){
	int head = 0;
	int dis = 0;
	int i = queue[head].i;
	int j = queue[head].j;
	if (game_bd_value[i][j] == 10){
		should_del(i, j);
		if (j - 1 >= 0){
			dis = game_bd_value[i][j - 1];
			for (int m = 0; m < g_width;m++)
			for (int n = 0; n < game_bd_num[m]; n++){
				if (game_bd_value[m][n] == dis)should_del(m, n);
			}
		}
	}
	else if (game_bd_value[i][j] == 20){
		should_del(i, j);
		if (j - 1 >= 0){
			dis = game_bd_value[i][j - 1];
			for (int m = 0; m < g_width; m++)
			for (int n = 0; n < game_bd_num[m]; n++){
				if (game_bd_value[m][n] == dis){
					check1(2,m,n);
					check2(2, m, n);
					check3(2, m, n);
					check4(2, m, n);
				}
			}
		}
	}
	else{
		while (head != g_queue_cnt)
		{
			i = queue[head].i;
			j = queue[head].j;
			if (game_bd_status[i][j] == MODIFYED){
				check1(3,i,j);
				check2(3, i, j);
				check3(3, i, j);
				check4(3, i, j);
				if (game_bd_status[i][j] == MODIFYED)game_bd_status[i][j] = 0;
			}

			head++;
		}
	}
}


void disappear(){
	int mvd = 0;
	int p;
	for (int m = 0; m < g_width; m++){
		p = 0;
		mvd = 0;
		for (int n = 0; n < game_bd_num[m]; n++){
			if (game_bd_status[m][n] == CANRM){
				mvd = 1;
			}
			else
			{
				game_bd_value[m][p] = game_bd_value[m][n];
				game_bd_status[m][p] = game_bd_status[m][n];
				if (mvd)in_queue_modify(m, p);
				p++;
			}
		
		}
		for (int n = p; n < game_bd_num[m]; n++){
		 game_bd_value[m][n]=0;
		 game_bd_status[m][n]=0;
		}
		game_bd_num[m] = p;

	}
}
/////////////////////////////////
void init(int width) {
	g_width = width;
	for (int i = 0; i < g_width; i++){
		game_bd_num[i] = 0;
		for (int j = 0; j < MAX_HIGHT; j++){
			game_bd_status[i][j]= 0;
			game_bd_value[i][j] = 0;
		}
	}
	g_queue_cnt=0;
}

void newBlock(int block[BLOCK_SIZE]) {
	blk[2] = block[0];
	blk[1] = block[1];
	blk[0] = block[2];
	g_mv = 0;
}

void specialBlock(int type) {
	blk[0] = type*10;
	blk[1] = 0;
	blk[2] = 0;
	g_mv = 0;
}

void circulate(int count) {
	int c = count % 3;
	int tmp;
	if (c == 1){
		tmp = blk[0];
		blk[0] = blk[1];
		blk[1] = blk[2];
		blk[2] = tmp;
	}
	else if (c == 2){
		tmp = blk[0];
		blk[0] = blk[2];
		blk[2] = blk[1];
		blk[1] = tmp;
	}
}

void move(int distance) {
	g_mv += distance;
	if (g_mv < 0){
		g_mv = 0;
	}
	else if(g_mv>g_width-1){
		g_mv = g_width-1;
	}
}

int land() {
	down_b();
	while (g_queue_cnt!=0){
		check();//check and set disappear 
		g_queue_cnt = 0;
		disappear(); //disappear and set changed point
	}

	return get_cricls();
}

