void init(int N) {

}

void addBuilding(int id, int locX, int locY, int w, int h, int px, int py) {

}

int getDistance(int from, int to) {
	return 0;
}