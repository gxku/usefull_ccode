import java.util.Scanner;

class Solution {
	private static Scanner sc;

	private static int Score = 0;

	static final int CMD_INIT = 0;
	static final int CMD_ADD = 1;
	static final int CMD_GET = 2;
	static final int CMD_EXIT = 9;

	private static UserSolution user = new UserSolution();

	private static void run() {
		int N, cmd;
		int id, locX, locY, w, h, px, py;
		int from, to, dist, ret;

		cmd = sc.nextInt();
		N = sc.nextInt();
		
		Score = 0;
		user.init(N);
		while (true) {
			cmd = sc.nextInt();
			if (cmd == CMD_ADD) {
				id = sc.nextInt();
				locX = sc.nextInt();
				locY = sc.nextInt();
				w = sc.nextInt();
				h = sc.nextInt();
				px = sc.nextInt();
				py = sc.nextInt();
				user.addBuilding(id, locX, locY, w, h, px, py);
			} else if (cmd == CMD_GET) {
				from = sc.nextInt();
				to = sc.nextInt();
				dist = sc.nextInt();
				ret = user.getDistance(from, to);
				if (ret == dist)
					Score++;
			} else if (cmd == CMD_EXIT)
				break;
		}
	}

	public static void main(String[] args) throws Exception {
		// System.setIn(new java.io.FileInputStream("sample_input.txt"));
		sc = new Scanner(System.in);
		int T;
		T = sc.nextInt();
		int TotalScore = 0;
		for (int test_case = 1; test_case <= T; test_case++) {
			run();
			TotalScore += Score;
			System.out.print("#" + test_case + " " + Score + "\n");
		}
		System.out.print("Total Score = " + TotalScore + "\n");
		sc.close();
	}
}