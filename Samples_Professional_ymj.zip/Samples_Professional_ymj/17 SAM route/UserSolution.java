class UserSolution {

	public void init(int N) {

	}

	public void addBuilding(int id, int locX, int locY, int w, int h, int px, int py) {

	}

	public int getDistance(int from, int to) {
		return 0;
	}
}