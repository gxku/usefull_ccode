#define MAX_OD 10000
#define MAX_TM  21000

// API
extern int startcook(int chefid, int orderid);
extern int finishcook(int chefid);

typedef struct list{
	struct list *prev, *next;
}NODE;

struct ODER{
	NODE todo;
	NODE over;

	int orderid;
	int ordertime;
	int cookingtime;
	int waitingtime;
	int price;
	int priority_H;
	int priority_L;
}oders[MAX_OD];
int g_chef;
int g_idle_chef;
int g_index;

NODE todo_list[502];
int todo_list_num[502];
NODE over_list[MAX_TM];
int over_list_num[MAX_TM];
int doing_list[33];

//////////////////////////////////////////
void list_init(struct list *head){
	head->next = head->prev = head;
}

void _list_add(NODE *now,NODE *prev,NODE*next){
	now->next = next;
	now->prev = prev;
	prev->next = now;
	next->prev = now;
}

void list_add(NODE * now,struct list *head){
	_list_add(now,head,head->next);
}

void list_add_tail(NODE * now, struct list *head){
	_list_add(now, head->prev, head);
}

void list_del(NODE *now){
	now->next->prev = now->prev;
	now->prev->next = now->next;
	now->next = now->prev = now;
}

#define todo_to_order(node)  ((struct ODER*)(node))
#define over_to_order(node)  ((struct ODER*)((char*)node-sizeof(NODE)))
//////////////////////////////////////////
void insert_todolist(struct ODER *od){
	int p_H = od->priority_H;
	int p_L = od->priority_L;
	int cookingtime = od->cookingtime;
	NODE *root = &todo_list[p_H];
	NODE *node=root->next;
	todo_list_num[p_H]++;
		while (root != node){
			if (todo_to_order(node)->priority_L < p_L){
				_list_add(&od->todo, node->prev, node);
				return;
			}
			else if (todo_to_order(node)->priority_L == p_L)
			{
				if (todo_to_order(node)->cookingtime > cookingtime){
					_list_add(&od->todo, node->prev, node);
					return;
				}
			}
			node = node->next;
		}

		if (root == node){
			list_add_tail(&od->todo,root);
		}
}


int get_first_odid(){
	for (int i = 501; i >= 0; i--){
		if (todo_list_num[i] > 0){
			return  todo_to_order(todo_list[i].next)->orderid;
		}
	}
	return -1;
}

void finish_last_tick(int currenttime){
	int odid;
	NODE *root;
	NODE *node;
	if (g_idle_chef != g_chef){
		for (int i = 1; i <= g_chef; i++){
			odid = doing_list[i];
			if (odid == -1)continue;
			oders[odid].cookingtime--;
			if (oders[odid].cookingtime == 0){
				finishcook(i);
				doing_list[i] = -1;
				g_idle_chef++;
			}
			else if (oders[odid].ordertime + oders[odid].waitingtime==currenttime){
				doing_list[i] = -1;
				g_idle_chef++;
			}
		}
	}
	if (over_list_num[currenttime] != 0){
		root = &over_list[currenttime];
		node = root->next;
		while (root!=node)
		{
			list_del(&over_to_order(node)->todo);
			todo_list_num[over_to_order(node)->priority_H]--;
			node = node->next;
		}
		over_list_num[currenttime] = 0;
	}
}

int get_mini_id(){
	int min_id = 1;
	int odid;
	float min_p = oders[min_id].price / (float)oders[min_id].cookingtime;
	float tmp_p;
	for (int i = 2; i <=g_chef; i++){
		odid = doing_list[i];
		tmp_p = oders[odid].price / (float)oders[odid].cookingtime;
		if (min_p>tmp_p){
			min_p = tmp_p;
			min_id = i;
		}
	}
	return min_id;
}

int try_cook(int odid){
	int min_id;
	if (g_idle_chef != 0){
		for (int i = 1; i <= g_chef; i++){
			//odid = doing_list[i];
			if (doing_list[i] == -1){
				doing_list[i] = odid;
				list_del(&(oders[odid].todo));
				todo_list_num[oders[odid].priority_H]--;
				g_idle_chef--;
				return i;
			}
		}
	}
	else{
		min_id = get_mini_id();
		if (oders[doing_list[min_id]].priority_H < oders[odid].priority_H){
			insert_todolist(&oders[doing_list[min_id]]);
			doing_list[min_id] = odid;
			list_del(&oders[odid].todo);
			todo_list_num[oders[odid].priority_H]--;
			return min_id;
		}
		else if (oders[doing_list[min_id]].priority_H == oders[odid].priority_H)
		{
			if (oders[doing_list[min_id]].priority_L < oders[odid].priority_L){
				insert_todolist(&oders[doing_list[min_id]]);
				doing_list[min_id] = odid;
				list_del(&oders[odid].todo);
				todo_list_num[oders[odid].priority_H]--;
				return min_id;
			}
			else if (oders[doing_list[min_id]].priority_L == oders[odid].priority_L)
			{
				if (oders[doing_list[min_id]].cookingtime > oders[odid].cookingtime){
					insert_todolist(&oders[doing_list[min_id]]);
					doing_list[min_id] = odid;
					list_del(&oders[odid].todo);
					todo_list_num[oders[odid].priority_H]--;
					return min_id;
				}
			}
		}
	}
	return -1;
}

void what_todo_this_tick(int currenttime){
	int odid;// = get_first_odid();
	int chef_id = 0;
	//if (odid == -1)return;

	while (1){
		odid = get_first_odid();
		if (odid == -1)return;
		chef_id = try_cook(odid);
		if (chef_id == -1)return;
		startcook(chef_id, odid);
	

	}
}
//////////////////////////////////////////
// User Implementation
void init(int N) {
	//1 ~ 32
	g_chef = N;
	g_idle_chef = N;
	g_index = 1;

	for (int i = 1; i <= N; i++){
		doing_list[i] = -1;
	}
	for (int i = 0; i < 502; i++){
		list_init(&todo_list[i]);
		todo_list_num[i] = 0;
	}
	for (int i = 0; i < MAX_TM; i++){
		list_init(&over_list[i]);
		over_list_num[i] = 0;
	}

}

void takeorder(int orderid, int ordertime, int price, int cookingtime, int waitingtime) {
	/*
	orderid 1~10000
	ordertime 0~19999
	price 1~1000
	cooking time 1~200
	waitfing time 1~1000
	*/
	struct ODER *od = &oders[g_index++];
	od->orderid = orderid;
	od->ordertime = ordertime;
	od->cookingtime = cookingtime;
	od->waitingtime = waitingtime;
	od->price = price;
	od->priority_H = price / cookingtime;
	if (od->priority_H > 500)od->priority_H = 501;//1000 500,
	od->priority_L = (price % cookingtime) / cookingtime;

	if (ordertime == 6)
		ordertime == 6;


	insert_todolist(od);
	list_add(&od->over, &over_list[ordertime + waitingtime]);
	over_list_num[ordertime + waitingtime]++;
}

void tick(int currenttime) {
	/*
	0~19999
	*/
	if (currenttime == 5)
		currenttime == 5;
	//
	finish_last_tick(currenttime);


	//start
	what_todo_this_tick(currenttime);
}