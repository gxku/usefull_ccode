class UserSolution {
	// Main API :
	//   Solution.startcook(int chefid, int orderid)
	//   Solution.finishcook(int chefid)

	public void init(int N) {
		//A function that is called at the beginning of each test case for initialization
		//N refers to the number of chefs in the restaurant
		
	}

	public void takeorder(int orderid, int ordertime, int price, int cookingtime, int waitingtime) {
		//A function that is called when a customer comes to the restaurant and places an order
		//orderid: sequentially [1,10000]
		//ordertime:[0,19999]
		//price:[1,1000]
		//cookingtime:[1,200]
		//waitingtime:[1,1000]
	}

	public void tick(int currenttime) {
		//tick function is called every hour
		//Handles a customer's order using an API provided in the Main part
		//currenttime:[0,19999]

	}
}