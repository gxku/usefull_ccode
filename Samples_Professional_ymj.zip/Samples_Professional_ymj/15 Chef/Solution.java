import java.util.Scanner;

class Solution {
	private final static int MAXCHEF = 32;
	private final static int MAXORDER = 10000;

	private final static int OK = 1;
	private final static int NOTOK = 0;

	private final static int SAMPLE_CUTLINE = 51;
	private final static int EVAL_CUTLINE = 74;  // it can be changed in evaluation.

	private static class Order {
		public int ordertime;
		public int price;
		public int cookingtime;
		public int waitingtime;
		public int chefid;
		public int done;
	}

	private static int M;                             // the number of orders 
	private static int orderidx;
	private static Order order[] = new Order[MAXORDER + 1];

	private static class Chef {
		public int orderid;
		public int startcookingtime;
	}

	private static int N;                              // the number of chefs
	private static Chef chef[] = new Chef[MAXCHEF + 1];

	private static int endtime;
	private static int currenttime;
	private static int earned;
	private static int total;
	private static int okay;

	private static UserSolution usersolution = new UserSolution();

	// The below commented code is reference code for testcase generation.
	// It is provided for your reference and it does not work.
	//
	// int M;  // the number of orders
	//
	// Random rand = new Random();
	//
	// for (int idx = 1; idx <= M; ) {
	//   order[idx] = new Order();
	//   order[idx].ordertime = rand.nextInt(MAXTIME + 1);
	//   order[idx].price = rand.nextInt(MAXPRICE - MINPRICE + 1) + MINPRICE;
	//   order[idx].cookingtime = rand.nextInt(MAXCOOKINGTIME - MINCOOKINGTIME + 1) + MINCOOKINGTIME;
	//   order[idx].waitingtime = rand.nextInt(MAXWAITINGTIME - order[idx].cookingtime + 1) + order[idx].cookingtime;
	//   order[idx].chefid = -1;
	//   order[idx].done = NOTOK;
	//
	//   if (order[idx].ordertime + order[idx].waitingtime > MAXTIME) continue;
	//   idx++;
	// }
	//
	//  Arrays.sort(order, 1, M + 1);  // sort by ordertime

	public static int startcook(int chefid, int orderid) {
		//A function that assigns orders to chefs
		//OK if successful
		if (chefid <= 0 || chefid > N)
			return okay = NOTOK;

		if (orderid <= 0 || orderid > M || order[orderid].ordertime > currenttime || order[orderid].chefid != -1)
			return okay = NOTOK;

		if (chef[chefid].orderid != -1) {
			order[chef[chefid].orderid].cookingtime -= currenttime - chef[chefid].startcookingtime;
			order[chef[chefid].orderid].chefid = -1;
		}

		chef[chefid].orderid = orderid;
		chef[chefid].startcookingtime = currenttime;

		order[orderid].chefid = chefid;

		return OK;
	}

	public static int finishcook(int chefid) {
		//A function that finishes cooking and serves the finished dish to the customer
		//If successful, the customer pays for the dish
		//The function should not be called before the order is finished or after the waiting time has passed.
		//In that case, the corresponding test case cannot obtain a score
		//OK if the payment is made
		if (chefid <= 0 || chefid > N || chef[chefid].orderid == -1)
			return okay = NOTOK;

		int orderid = chef[chefid].orderid;
		if (order[orderid].done == OK)
			return okay = NOTOK;

		int elapsedtime = currenttime - chef[chefid].startcookingtime;
		if (elapsedtime < order[orderid].cookingtime)
			return okay = NOTOK;

		if (currenttime > order[orderid].ordertime + order[orderid].waitingtime)
			return okay = NOTOK;

		earned += order[orderid].price;
		order[orderid].done = OK;

		chef[chefid].orderid = -1;

		return OK;
	}

	private static void read(Scanner sc) {
		N = sc.nextInt();//1 chef
		M = sc.nextInt();//5 orders
		endtime = sc.nextInt();//10 

		total = 0;

		for (int idx = 1; idx <= M; ++idx) {
			order[idx] = new Order();
			order[idx].ordertime = sc.nextInt();
			order[idx].price = sc.nextInt();
			order[idx].cookingtime = sc.nextInt();
			order[idx].waitingtime = sc.nextInt();
			order[idx].chefid = -1;
			order[idx].done = NOTOK;
			total += order[idx].price;
		}
	}

	private static void doticking(int currenttime) {
		while (orderidx <= M && order[orderidx].ordertime == currenttime) {
			usersolution.takeorder(orderidx,
				order[orderidx].ordertime,
				order[orderidx].price,
				order[orderidx].cookingtime,
				order[orderidx].waitingtime);
			orderidx++;
		}

		usersolution.tick(currenttime);
	}

	public static void main(String[] args) throws Exception{
		int TC, totalscore;

		//System.setIn(new java.io.FileInputStream("res/sample_input.txt"));
		Scanner sc = new Scanner(System.in);
		TC = sc.nextInt();//5

		totalscore = 0;
		for (int testcase = 1; testcase <= TC; ++testcase) {
			read(sc);

			for (int idx = 1; idx <= N; ++idx) {
				chef[idx] = new Chef();
				chef[idx].orderid = -1;
			}

			earned = 0;
			orderidx = 1;

			usersolution.init(N);

			for (currenttime = 0, okay = OK; okay == OK && currenttime <= endtime; ++currenttime)
				doticking(currenttime);

			int point = okay == OK ? earned * 100 / total : 0;
			totalscore += point >= SAMPLE_CUTLINE ? 100 : 0;

			System.out.println("#" + testcase + " " + (earned * 100 / total));
		}

		System.out.println("total score = " + totalscore / TC);
		sc.close();
	}
}