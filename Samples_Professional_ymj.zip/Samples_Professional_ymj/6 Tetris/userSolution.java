class UserSolution {
    private static final int BOARD_MAX_WIDTH = 10;
    private static final int BOARD_MAX_HEIGHT = 200;
    private static final int BLOCK_MAX_SIZE = 3;
    private static final int ROTATE_90 = 1;
    private static final int ROTATE_180 = 2;
    private static final int ROTATE_270 = 3;
    private static final int ROTATE_360 = 4;

    

    public void init(int width) {

    }
    
    public void newBlock(int block[][], int width, int height) {

    }

    public void rotate(int angle) {  // 1: ROTATE_90, 2: ROTATE_180, 3: ROTATE_270, 4: ROTATE_360

    }
    
    void move(int distance) 
    {

    }
    
    int land() {
        int answer = -1;

        return answer;
    }

    
    
}
