#define BOARD_MAX_WIDTH     10		//宽度 5~10
#define BOARD_MAX_HEIGHT    200		//高度 200
#define BLOCK_MAX_SIZE      3		//方块最大3*3
#define ROTATE_90           1    
#define ROTATE_180          2
#define ROTATE_270          3
#define ROTATE_360          4


void init(int width)
{

}

void newBlock(int block[BLOCK_MAX_SIZE][BLOCK_MAX_SIZE], int width, int height)
{

}

void rotate(int angle)	// 1: ROTATE_90, 2: ROTATE_180, 3: ROTATE_270, 4: ROTATE_360
{  

}

void move(int distance)
{

}

int land()
{
	return -1;
}