
class UserSolution 
{
	void InitDB()
	{


	}

	void Add(String name, String number, String birthday, String email, String memo)
	{

	}


	int Delete(int field, String str)
	{
	
		return -1;
	}

	int Change(int field, String str, int changefield, String changestr)
	{

		return -1;
	}

	Solution.Result Search(int field, String str, int returnfield)
	{
		Solution.Result result = new Solution.Result();
		result.count = -1;
		
		return result;
	}
}
