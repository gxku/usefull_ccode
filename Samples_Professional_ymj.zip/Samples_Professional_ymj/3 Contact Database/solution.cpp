#define LEN 20
#define MAX 50000
#define HASH_M 131313

typedef enum
{
	NAME,
	NUMBER,
	BIRTHDAY,
	EMAIL,
	MEMO
} FIELD;

typedef struct
{
	int count;
	char str[20];
} RESULT;


typedef struct list{
	struct list *prev, *next;
}NODE;



NODE hash_tab[5][HASH_M];


int   hash_num[5][HASH_M];


struct CONTACT{
	NODE list[5];
	char str[5][LEN];
	int hash_value[5];
}contacts[MAX];

int g_index;
////////////////////////////////////////////////////////////////////////////////
void list_init(struct list *head){
	head->next = head->prev = head;
}

void _list_add(NODE *now, NODE* prev, NODE *next){
	now->next = next;
	now->prev = prev;
	prev->next = now;
	next->prev = now;
}

void list_add(NODE* now, struct list* head){
	_list_add(now, head, head->next);
}

void list_del(NODE* now){
	now->next->prev = now->prev;
	now->prev->next = now->next;
	now->next = now->prev = now;
}

#define name_to_cont(node)   ((struct CONTACT*)(node))
#define number_to_cont(node) ((struct CONTACT*)((char*)node-sizeof(NODE)))
#define birthday_to_cont(node)  ((struct CONTACT*)((char*)node-2*sizeof(NODE)))
#define email_to_cont(node)   ((struct CONTACT*)((char*)node-3*sizeof(NODE)))
#define memo_to_cont(node)   ((struct CONTACT*)((char*)node-4*sizeof(NODE)))

struct CONTACT* field_to_cont(FIELD field,NODE *node){

	switch (field)
	{
	case	NAME:
		return name_to_cont(node);

		break;
	case	NUMBER:
		return	number_to_cont(node);
		break;
	case	BIRTHDAY:
		return	birthday_to_cont(node);

		break;
	case	EMAIL:
		return	email_to_cont(node);
		break;
	case	MEMO:
		return	memo_to_cont(node);
		break;
	default:
		return 0;
		break;
	}
	

}
////////////////////////////////////////////////////////////////////////////////
void str_cp(char*to, char* from){
	while (*from != '\0')
	{
		*to++ = *from++;
	}
	*to++ = *from++;
}
int str_cp_hash(char*to, char* from){
	int h = 0;
	int seed = 1313;
	while (*from != '\0')
	{
		h = (h*seed + *from) % HASH_M;
		*to++ = *from++;

	}
	*to++ = *from++;
	return h;
}
int str_eq(char* a, char* b){
	while (*a != '\0'&&*b != '\0'&&*a == *b){
		a++;
		b++;
	}
	return *a - *b;

}

int hash(char* str){
	int h = 0;
	int seed = 1313;
	while (*str != '\0'){
		h = (h*seed + *str++) % HASH_M;
	}
	return h;
}
///////////////////////////////////////////////////////////////////////////////
void InitDB()
{
	for (int i = 0; i < HASH_M; i++){
		list_init(&hash_tab[0][i]);
		list_init(&hash_tab[1][i]);
		list_init(&hash_tab[2][i]);
		list_init(&hash_tab[3][i]);
		list_init(&hash_tab[4][i]);

		hash_num[0][i] = 0;
		hash_num[1][i] = 0;
		hash_num[2][i] = 0;
		hash_num[3][i] = 0;
		hash_num[4][i] = 0;
	}

	g_index = 0;
}

#define ADD_FIELD(field,str_field) do{                       \
	has = str_cp_hash(con->str[field], str_field);           \
	con->hash_value[field] = has;                            \
	list_add(&con->list[field], &hash_tab[field][has]);      \
	hash_num[field][has]++;                                  \
}while (0)

void Add(char* name, char* number, char* birthday, char* email, char* memo)
{
	struct CONTACT *con = &contacts[g_index++];
	int has;
	ADD_FIELD(0,name);
	ADD_FIELD(1,number);
	ADD_FIELD(2,birthday);
	ADD_FIELD(3,email);
	ADD_FIELD(4,memo);
}


int Delete(FIELD field, char* str)
{
	int ret = 0;
	int has = hash(str);
	int i;
	NODE * root;
	NODE * node;
	struct CONTACT *con;
	root = &hash_tab[field][has];          
		node = root->next;                       
		while (root != node){

			con = field_to_cont(field, node);
			node = node->next;
			if (str_eq(con->str[field], str) == 0){

				for (i = 0; i < 5; i++){
					list_del(&con->list[i]);
					hash_num[i][con->hash_value[i]]--;
				}

				ret++;
			}
		}
	return ret;
}



int Change(FIELD field, char* str, FIELD changefield, char* changestr)
{
	int ret = 0;
	int has = hash(str);
	NODE * root;
	NODE * node;
	struct CONTACT *con;

	root = &hash_tab[field][has];
	node = root->next;                    
	while (root != node)
	{
		
		con = field_to_cont(field, node);
		node = node->next;
		if (str_eq(con->str[field], str) == 0){

			ret++;
			has = hash(con->str[changefield]);
			hash_num[changefield][has]--;
			list_del(&con->list[changefield]);
			has = str_cp_hash(con->str[changefield], changestr);
			list_add(&con->list[changefield], &hash_tab[changefield][has]);
			hash_num[changefield][has]++;
		}
		
	}
	return ret;
}



RESULT Search(FIELD field, char* str, FIELD ret_field)
{
	RESULT result;
	result.count = 0;
	int has = hash(str);
	NODE * root;
	NODE * node;

	root = &hash_tab[field][has];
	node = root->next;

	while (root != node)
	{
		if (str_eq(field_to_cont(field, node)->str[field], str) == 0){
			str_cp(result.str, field_to_cont(field, node)->str[ret_field]);
			result.count++;
		}
		node = node->next;
	}

	return result;
}




