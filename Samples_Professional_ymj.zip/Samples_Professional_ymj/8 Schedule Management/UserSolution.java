
class UserSolution 
{
	
	
	void Init()
	{
		
		
	}
	
	void Add(int id, String title, String location, String start_date, String end_date)
	{
		
		
	}



	int Modify(int id, String title, String location, String start_date, String end_date)
	{
		
		 return 0;
	}

	int Delete(int id){
		
	}

	Solution.RESULT Search(int type, String str){
		Solution.RESULT result = new Solution.RESULT();
		result.count = 0;
				
		return result;
	}