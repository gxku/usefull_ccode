#define L_TIME 12;
#define L_STR 19
#define MAX  13131

typedef enum{
	SEARCH_TYPE_TITLE,
	SEARCH_TYPE_LOCATION,
	SEARCH_TYPE_DATE
} SEARCH_TYPE;

typedef struct{
	int count;
	int id_list[10000];
} RESULT;


typedef struct list{
	struct list *prev, *next;
}NODE;

struct SCHED{
	struct list tile_list;
	struct list loc_list;
	struct list stime_list;

	int id;
	char title[L_STR];
	int title_hash;
	char location[L_STR];
	int loc_hash;

	int s_year;
	int s_moth;
	int s_day;
	long long s_YMD;
	long long s_date;

	int e_year;
	int e_moth;
	int e_day;
	long long e_YMD;
	long long e_date;

	int ok;
}scheld[MAX];

struct list hash_titl_tab[MAX];
int hash_titl_tab_num[MAX];
struct list hash_loc_tab[MAX];
int hash_loc_tab_num[MAX];
struct list time_tab[100][12][31];
struct SCHED *id_tab[MAX];

int g_index;

int Delete(int id);
/////////////////////////////////////////////////////////
void list_init(struct list *head){
	head->next = head->prev = head;
}

void _list_add(NODE * now,NODE *prev,NODE *next){
	now->next = next;
	now->prev = prev;
	prev->next = now;
	next->prev = now;
}

void list_add(NODE* node,struct list* head){
	_list_add(node,head,head->next);
}

void list_add_tail(NODE* node, struct list* head){
	_list_add(node, head->prev, head);
}

void list_del(NODE *node){
	node->next->prev = node->prev;
	node->prev->next = node->next;
	node->next = node->prev = node;
}

#define tilt_to_scheld(node)  ((struct SCHED*)(node))
#define loc_to_scheld(node)  ((struct SCHED*)((char*)(node)-sizeof(struct list)))
#define stime_to_scheld(node)  ((struct SCHED*)((char*)(node)-2*sizeof(struct list)))

#define get_id(node)  (node->id)
#define title_get_id(title)  get_id(tilt_to_scheld(title))
#define loc_get_id(loc)  get_id(loc_to_scheld(loc))
#define stime_get_id(time) get_id(stime_to_scheld(time))
////////////////////////////////////////////////////////
void inline str_cp(char* from,char* to){
	while (*from!='\0'){
		*to++ = *from++;
	}
	*to++ = *from++;
}

int inline str_eq(char* a, char*b){
	while (*a != '\0'&&*b != '\0'&&*a == *b){
		a++;
		b++;
	}
	return *a - *b;
}

int inline hash(char *str){
	unsigned int h = 0;
	int seed = 1313;
	while (*str)
	{
		h = (h*seed + *str++) % MAX;
	}
	return h;
}

int inline str_to_int(char* str, int s, int n){
	int ret = 0;
	for (int i = s; i < s + n; i++){
		ret = ret * 10 + str[i] - '0';
	}
	return ret;
}
void inline setup_title_and_loc(struct SCHED* scd, char* title, char* location){
	str_cp(title,scd->title);
	str_cp(location,scd->location);
	scd->title_hash = hash(title);
	scd->loc_hash = hash(location);
}

void inline setup_time(struct SCHED* scd, char* start_date, char* end_date){
	
	scd->s_year = str_to_int(start_date, 0, 4);
	scd->s_moth = str_to_int(start_date, 4, 2);
	scd->s_day = str_to_int(start_date, 6, 2);
	scd->s_YMD = scd->s_year * 10000 + scd->s_moth * 100 + scd->s_day;
	scd->s_date = scd->s_YMD * 10000 + str_to_int(start_date, 8, 4);
	   
	scd->e_year = str_to_int(end_date, 0, 4);
	scd->e_moth = str_to_int(end_date, 4, 2);
	scd->e_day = str_to_int(end_date, 6, 2);
	scd->e_YMD = scd->e_year * 10000 + scd->e_moth * 100 + scd->e_day;
	scd->e_date = scd->e_YMD * 10000 + str_to_int(end_date, 8, 4);
}
void inline time_list_add(struct SCHED* scd, struct list time_tab[100][12][31]){
	int year = scd->s_year;
	int moth = scd->s_moth;
	int day = scd->s_day;

	NODE* root = &time_tab[year-2000-1][moth-1][day-1];
	NODE* node = root->next;
	while (root != node){
		if (stime_to_scheld(node)->s_date < scd->s_date){
			node = node->next;
		}
		else{
			_list_add(&scd->stime_list,node->prev,node);
			return;
		}

	}
	list_add(&scd->stime_list,root);

}

long long min(long long a, long long b){
	return a < b ? a : b;
}

long long get_min(long long a, long long b, long long c, long long d){
	long long tmp1 = min(a, b);
	long long tmp2 = min(c, d);
	return min(tmp1, tmp2);
}

long long max(long long a, long long b){
	return a > b ? a : b;
}

long long get_max(long long a, long long b, long long c, long long d){
	long long tmp1 = max(a,b);
	long long tmp2 = max(c,d);
	return max(tmp1,tmp2);
}

int overlep(struct SCHED*  scd, struct SCHED* scd2, long long *s_time, long long *e_time){
	long long max = get_max(scd->s_date,scd->e_date,scd2->s_date,scd2->e_date);
	long long min = get_min(scd->s_date, scd->e_date, scd2->s_date, scd2->e_date);

	if (max - min > scd->e_date - scd->s_date + scd2->e_date - scd2->s_date){
		return 0;
	}
	else{
		*s_time = min;
		*e_time = max;
		return 1;
	}

}

void merge(struct SCHED* scd, long long s_time, long long e_time){

		list_del(&scd->stime_list);
		scd->s_date = s_time;
		scd->s_YMD = s_time / 10000;
		scd->s_year = scd->s_YMD / 10000;
		scd->s_moth = scd->s_YMD % 10000 / 100;
		scd->s_day = scd->s_YMD % 100;
		
		scd->e_date = e_time;
		scd->e_YMD = e_time / 10000;
		scd->e_year = scd->e_YMD / 10000;
		scd->e_moth = scd->e_YMD % 10000 / 100;
		scd->e_day = scd->e_YMD % 100;

		time_list_add(scd, time_tab);
}

void try_merge(int id){
	struct SCHED* scd = id_tab[id];
	struct SCHED* scd2;
	long long s_time;
	long long e_time;
	if (hash_titl_tab_num[scd->title_hash] <= 1 || hash_loc_tab_num[scd->loc_hash] <= 1)
		return;
	NODE *root = &hash_titl_tab[scd->title_hash];
	NODE *node = root->next;
	while (root!=node){
		scd2 = tilt_to_scheld(node);
		if (scd!=scd2 && str_eq(scd->title, scd2->title) == 0 && str_eq(scd->location, scd2->location) == 0){
			if (overlep(scd, scd2,&s_time,&e_time) == 1){
				if (get_id(scd) < get_id(scd2)){
					merge(scd,s_time,e_time);
					node = node->next;
					Delete(get_id(scd2));
					continue;
				}
				else{
					merge(scd2,s_time,e_time);
					Delete(get_id(scd));
					scd = scd2;
					
				}
			}
		}
		node = node->next;
	}
}

///////////////////////////////////////////////////////
void Init(){

	for (int i = 0; i < MAX; i++){
		list_init(&hash_titl_tab[i]);
		hash_titl_tab_num[i]=0;
		hash_loc_tab_num[i]=0;
		list_init(&hash_loc_tab[i]);
		id_tab[i] = 0;
	}

	for (int i = 0; i < 100;i++)
	for (int j = 0; j < 12; j++)
	for (int k = 0; k < 31; k++){
		list_init(&time_tab[i][j][k]);
	}
	g_index=0;
}

void Add(int id, char* title, char* location, char* start_date, char* end_date){
	struct SCHED* scd = &scheld[g_index++];
	id_tab[id] = scd;
	scd->ok = 1;
	scd->id = id;
	setup_title_and_loc(scd,title,location);
	setup_time(scd,start_date,end_date);
	

	list_add(&scd->tile_list, &hash_titl_tab[scd->title_hash]);
	hash_titl_tab_num[scd->title_hash]++;
	list_add(&scd->loc_list, &hash_loc_tab[scd->loc_hash]);
	hash_loc_tab_num[scd->loc_hash]++;
	time_list_add(scd,time_tab);

	try_merge(id);
}

int Modify(int id, char* title, char* location, char* start_date, char* end_date){

	if (id_tab[id]==0)
		return 1;
	struct SCHED* scd = id_tab[id];

	if (scd->ok == 0)
		return 1;
	Delete(id);
	Add(id,title,location,start_date,end_date);

	return 0;
}

int Delete(int id){
	if (id_tab[id] == 0)
		return 1;
	struct SCHED* scd = id_tab[id];

	if (scd->ok == 0)
		return 1;

	scd->ok = 0;
	list_del(&scd->loc_list);
	hash_loc_tab_num[scd->loc_hash]--;
	list_del(&scd->stime_list);
	list_del(&scd->tile_list);
	hash_titl_tab_num[scd->title_hash]--;
	id_tab[id] = 0;
	return 0;
}

RESULT Search(SEARCH_TYPE type, char* str){
	RESULT result;
	int has;
	NODE *root;
	NODE *node;
	int s_year;
	int	s_moth;
	int	s_day;
	long long	s_YMD;

	result.count = 0;
	switch (type)
	{
	case SEARCH_TYPE_TITLE:
		 has = hash(str);
		root = &hash_titl_tab[has];
		node = root->next;
		while (root != node){
			if(str_eq(str,tilt_to_scheld(node)->title)==0)result.id_list[result.count++] = title_get_id(node);
			node = node->next;
		}
		break;
	case SEARCH_TYPE_LOCATION:
		 has = hash(str);
		root = &hash_loc_tab[has];
		node = root->next;
		while (root != node){
			if (str_eq(str, loc_to_scheld(node)->location) == 0)result.id_list[result.count++] = loc_get_id(node);
			node = node->next;
		}
		break;
	case SEARCH_TYPE_DATE:
		s_year = str_to_int(str, 0, 4);
		s_moth = str_to_int(str, 4, 2);
		s_day = str_to_int(str, 6, 2);
		s_YMD = s_year * 10000 + s_moth * 100 + s_day;
		/*
		root = &time_tab;
		node = root->next;
		while (1){
			
		}
*/
		for (int i = 1; i < g_index + 10; i++){
			if (id_tab[i]!=0 && id_tab[i]->ok){
				if (id_tab[i]->s_YMD <= s_YMD && id_tab[i]->e_YMD >= s_YMD){
					result.id_list[result.count++] = i;
				}
			}
		}
		
		break;
	default:
		break;
	}
	return result;
}