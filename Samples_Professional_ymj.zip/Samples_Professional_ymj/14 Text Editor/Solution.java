import java.util.Scanner;

class Solution {

	static final int CMD_MOVECURSOR = 0;
	static final int CMD_REVERT = 1;
	static final int CMD_INPUT = 2;
	static final int CMD_GETSUBSTRING = 9;

	private static int N;
	private static int totalScore, curScore;

	private static Scanner sc;
	private static UserSolution user = new UserSolution();

	private static void make_input() {
		String t = sc.next();

		char ch[] = new char[33];

		int len = t.length();
		for (int i = 0; i < len; i++) {
			ch[i] = t.charAt(i);
		}
		ch[len] = '\0';

		user.cmd_input(ch);
	}

	private static void run() {
		char res[] = new char[33];
		char ori[] = new char[33];

		N = sc.nextInt();

		user.init();

		for (int i = 0; i < N; i++) {
			int cmd = sc.nextInt();

			if (cmd == CMD_INPUT) {
				make_input();
			}
			else if (cmd == CMD_REVERT) {
				user.cmd_revert();
			}
			else if (cmd == CMD_MOVECURSOR) {
				int pos = sc.nextInt();
				user.cmd_movecursor(pos);
			}
			else if (cmd == CMD_GETSUBSTRING) {
				int pos = sc.nextInt();
				int len = sc.nextInt();

				String t = sc.next();
				int tlen = t.length();
				for (int j = 0; j < tlen; j++) {
					ori[j] = t.charAt(j);
				}
				ori[tlen] = '\0';

				user.get_substring(pos, len, res);
				if (mystrcmp(ori, res) != 0)
					curScore = 0;
			}
		}
	}

	private static int mystrcmp(char[] s1, char[] s2) {
		for (int i = 0; i <= 30; i++) {
			if (s1[i] != s2[i])
				break;

			if (s1[i] == '\0')
				return 0;
		}
		return 1;
	}

	public static void main(String[] args) throws Exception{
		//		System.setIn(new java.io.FileInputStream("sample_input.txt"));
		sc = new Scanner(System.in);

		int T = sc.nextInt();
		totalScore = 0;

		for (int test_case = 1; test_case <= T; test_case++) {
			curScore = 100;
			run();

			System.out.println("#" + test_case + " " + curScore);
			totalScore += curScore;
		}

		System.out.println("Total Score = " + totalScore / T);
		sc.close();
	}
}