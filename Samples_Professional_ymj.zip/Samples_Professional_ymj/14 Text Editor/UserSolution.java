class UserSolution {

	public void init() {

	}

	public void cmd_input(char ch[]) {

	}

	public void cmd_revert() {

	}

	public void cmd_movecursor(int mCursor) {

	}

	public void get_substring(int mPosition, int mLength, char res[]) {

	}
}