void init()
{
}

void cmd_input(char ch[])
{
}

void cmd_revert()
{
}

void cmd_movecursor(int mCursor)
{
}

void get_substring(int mPosition, int mLength, char res[])
{
}