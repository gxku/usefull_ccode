public class UserSolution {
	

	
	public void init(int track_size, int head)
	{
		// TO DO

		
	}
	
	public void request(int track)
	{
		// TO DO

	}
	

	public int fcfs(){
		int track_no = -1;	// TO DO : Need to be changed

		return track_no;
	}

	public int sstf(){
		int track_no = -1;	// TO DO : Need to be changed

		return track_no;
	}

	public int look(){
		int track_no = -1;	// TO DO : Need to be changed

		return track_no;
	}

	public int clook()
	{
		int track_no = -1;	// TO DO : Need to be changed
		
		return track_no;
	}

