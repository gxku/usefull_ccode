const int MAX = 100000;

void init(int track_size, int head){
	// TO DO
}

void request(int track){
	// TO DO
}

int fcfs(){
	int track_no = -1;	// TO DO : Need to be changed

	return track_no;
}

int sstf(){
	int track_no = -1;	// TO DO : Need to be changed

	return track_no;
}

int look(){
	int track_no = -1;	// TO DO : Need to be changed

	return track_no;
}

int clook(){
	int track_no = -1;	// TO DO : Need to be changed

	return track_no;
}
