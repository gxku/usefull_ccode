package windowsmanager;

import windowsmanager.Algorithm;

public class Solution {
	public static final int MAX_WIN = 500;
	public static final int WIDTH = 160;
	public static final int HEIGHT = 120;

	public static int DisBuf[][] = new int[HEIGHT][WIDTH];

	////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////

	public static void InitWinManager(int bgcolor)
	{
		// To do
		
		
		//Do not remove
		Algorithm.DisplayUpdate(DisBuf);
	}

	public static int CreateWindow(int parent, int x, int y, int width, int height, int bgcolor)
	{
		// To do
		
		
		//Do not remove
		Algorithm.DisplayUpdate(DisBuf);
		
		return -1;
	}

	public static void DestroyWindow (int handle)
	{
		// To do
		
		
		//Do not remove
		Algorithm.DisplayUpdate(DisBuf);
	}

	public static void FillRect (int handle, int x, int y, int width, int height, int color)
	{
		// To do
		
		
		//Do not remove
		Algorithm.DisplayUpdate(DisBuf);
	}

	public static void ActiveWindow(int handle)
	{
		// To do
		
		
		//Do not remove
		Algorithm.DisplayUpdate(DisBuf);
	}

	public static void Click(int x, int y)
	{
		// To do
		
		
		//Do not remove
		Algorithm.DisplayUpdate(DisBuf);
	}
}

