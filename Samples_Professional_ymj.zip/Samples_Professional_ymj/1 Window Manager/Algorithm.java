package windowsmanager;

import java.util.Scanner;
import windowsmanager.Solution;

public class Algorithm {
	public static final int MAX_WIN = 500;
	public static final int WIDTH = 160;
	public static final int HEIGHT = 120;
	private static final int CMD_INIT = 0;
	private static final int CMD_CREATE = 1;
	private static final int CMD_DESTROY = 2;
	private static final int CMD_FILLRECT = 3;
	private static final int CMD_ACTIVE = 4;
	private static final int CMD_CLICK = 5;

	public static int Score, ScoreIdx;
	public static int UpdateCheck;
	public static int CheckIdx, CheckSum;
	public static int mHandle[] = new int[MAX_WIN];
	public static Scanner input;

	public static void main(){
		input = new Scanner(System.in);
		int T = input.nextInt();
	
		int TotalScore = 0;
		for(int tc = 1; tc <= T; tc++)
		{
			init();
			
			run();
		
			if(Score < 0)
				Score = 0;
			
			TotalScore += Score;
			System.out.println("#"+tc+' '+Score);
		}
	
		System.out.println("TotalScore = " + TotalScore);
		input.close();
	}
	
	static void DisplayUpdate(int dispbuf[][])
	{
		int sum = 0;
		
		for(int i = 0 ; i < HEIGHT; i++)
			for(int k = 0 ; k < WIDTH; k++)
				sum+= dispbuf[i][k];
			
		if(sum % CheckIdx != CheckSum)
			Score -= ScoreIdx;
		
		UpdateCheck = 1;
	}

	static void init()
	{
		Score = 1000;
		
		for(int i = 0 ; i < MAX_WIN; i++)
			mHandle[i] = -1;
	}

	static void cmd_init()
	{
		int bgcolor = input.nextInt();
		
		Solution.InitWinManager(bgcolor);
	}


	static void cmd_create()
	{
		int parent, h, x, y, width, height, bgcolor;
		parent = input.nextInt();
		h = input.nextInt(); 
		x = input.nextInt();
		y = input.nextInt();
		width = input.nextInt();
		height = input.nextInt();
		bgcolor = input.nextInt();
		
		if(parent != -1)
			parent = mHandle[parent];
		
		mHandle[h] = Solution.CreateWindow(parent, x, y, width, height, bgcolor);
	}

	static void cmd_destroy()
	{
		int h = input.nextInt();
		
		Solution.DestroyWindow(mHandle[h]);
		mHandle[h] = -1;
	}

	static void cmd_fillrect()
	{
		int h, x, y, width, height, color;
		h = input.nextInt(); 
		x = input.nextInt();
		y = input.nextInt();
		width = input.nextInt();
		height = input.nextInt();
		color = input.nextInt();
		
		Solution.FillRect(mHandle[h], x, y, width, height, color);
	}

	static void cmd_active()
	{
		int h = input.nextInt();
		
		Solution.ActiveWindow(mHandle[h]);
	}

	static void cmd_click()
	{
		int x, y;
		x = input.nextInt();
		y = input.nextInt();
		
		Solution.Click(x,y);
	}

	static void run()
	{
		int N;
		N = input.nextInt();
		ScoreIdx = Score / N;
		if(ScoreIdx * N < Score)  ScoreIdx++;
		
		for(int i = 0 ; i < N; i++)
		{
			int cmd;
			cmd = input.nextInt();
			CheckIdx = input.nextInt();
			CheckSum = input.nextInt();
		
			UpdateCheck = 0;
			switch(cmd)
			{
				case CMD_INIT:		cmd_init();break;
				case CMD_CREATE:	cmd_create();break;
				case CMD_DESTROY:	cmd_destroy();break;
				case CMD_FILLRECT:	cmd_fillrect();break;
				case CMD_ACTIVE:	cmd_active();break;
				case CMD_CLICK:		cmd_click();break;
				default:break;
			}
			
			if(UpdateCheck == 0)
				Score -= (ScoreIdx * 10);
		}
	}

}
