#define MAX_WIN 500
#define WIDTH   160
#define HEIGHT  120


extern void DisplayUpdate(char dispbuf[HEIGHT][WIDTH]);

char DisBuf[HEIGHT][WIDTH];

////////////////////////////////////////////////////////////////////////////////////////////////
struct WIN{
	int s_w;
	int s_h;
	int width;
	int height;
	char bgcolor;
	char buf[HEIGHT][WIDTH];


	int parent;
	int cnt;
	int child[MAX_WIN];
}winds[MAX_WIN];
int g_index;

int g_tree_index;
int trees[MAX_WIN+1];

int g_bgc;//bgcolor

void exchange(int *a, int *b){
	int tmp = *a;
	*a = *b;
	*b = tmp;
}

int get_tree_by_id(int id){
	while (winds[id].parent >= 0){
		id = winds[id].parent;
	}
	return id;
}

int cover_xy(int id,int w,int h){
	int s_w = winds[trees[id]].s_w;
	int e_w = s_w + winds[trees[id]].width;
	int s_h = winds[trees[id]].s_h;
	int e_h = s_h + winds[trees[id]].height;
	if (s_w <= w&& e_w > w&& s_h <= h&&e_h > h){
		return 1;
	}	
	else
	{
		return 0;
	}
}


int get_tree_by_xy(int w, int h){
	for (int id = g_tree_index - 1; id >= 0; id--){
		if (cover_xy(id,w, h))return trees[id];
	}
	return -1;
}

/////////////////////////////////////////////////////////////////////////
void clean(){
	for (int i = 0; i < HEIGHT; i++)
	for (int k = 0; k < WIDTH; k++)
		DisBuf[i][k] = g_bgc;
}

void do_show(int id,int p_w,int p_h,int v_w,int v_h,int v_W,int v_H){

	int s_w = winds[id].s_w;
	int s_h = winds[id].s_h;
	int w = winds[id].width;
	int h = winds[id].height;
	//p_w += s_w;
	//p_h += s_h;

	//int bgc = winds[id].bgcolor;

	int v_s_w = (p_w + s_w) > v_w ? (p_w + s_w) : v_w;
	int v_s_h = (p_h + s_h) > v_h ? (p_h + s_h) : v_h;

	int v_e_w = (p_w + s_w + w) < ( v_W) ? (p_w + s_w + w) : (v_W);
	int v_e_h = (p_h + s_h + h) < ( v_H) ? (p_h + s_h + h) : (v_H);
	if (v_s_w>=v_e_w || v_s_h>=v_e_h)return;

	int i, j, m, n;
	for (i = p_h + s_h, m = 0; i < s_h + p_h + h; i++, m++){
		for (j = p_w + s_w, n = 0; j < s_w + p_w + w; j++, n++){
			if (i >= v_s_h&&i < v_e_h && j >= v_s_w&&j < v_e_w)
				DisBuf[i][j] = winds[id].buf[m][n];

		}
	}

	for (int i = 0; i < winds[id].cnt; i++){
		do_show(winds[id].child[i], p_w + s_w, p_h + s_h, v_s_w, v_s_h, v_e_w, v_e_h);
	}

}

void show(){
	clean();
	int id = 0;
	//show TODO
	for (int tree_id = 0;tree_id< g_tree_index ; tree_id++){
		id = trees[tree_id];
		do_show(id,0,0,0,0,160,120);
	}
}


int do_CreateWindow(int parent, int w, int h, int width, int height, char bgcolor){
	int index = g_index++;
	int pid;

	winds[index].bgcolor = bgcolor;
	winds[index].cnt = 0;
	winds[index].s_w = w;
	winds[index].s_h = h;
	winds[index].height = height;
	winds[index].width = width;
	for (int i = 0; i < height; i++)
	for (int k = 0; k < width; k++){
		winds[index].buf[i][k] = bgcolor;
	}
	if (parent == -1){
		//pid = -1;/// *g_tree_index;
		trees[g_tree_index] = index;
		g_tree_index++;
	}
	else{
		pid = parent;
		winds[pid].child[winds[pid].cnt] = index;
		winds[pid].cnt++;
	}
	winds[index].parent = parent;

	return index;
}
int do_DestroyWindow(int handle){
	int pid = winds[handle].parent;
	if (pid < 0){
		
		//int tree_id = -1 * pid;
		for (int i = 0; i < g_tree_index-1; i++){
			if (trees[i] == handle)
				exchange(&trees[i], &trees[i + 1]);
		}
		g_tree_index--;
	}
	else{
		for (int i = 0; i < winds[pid].cnt-1; i++){
			if (winds[pid].child[i] == handle){
				exchange(&winds[pid].child[i], &winds[pid].child[i+1]);
			}

		}
		winds[pid].cnt--;
	}

	return 1;
}
int do_FillRect(int handle, int w, int h, int width, int height, char color){
	for (int i = h; i < h+height; i++)
	for (int k = w; k < w+width; k++){
		if(i>=0&&k>=0&&i<HEIGHT&&k<WIDTH)winds[handle].buf[i][k] = color;
	}
	return 1;
}
int do_ActiveWindow(int handle){
	int tree = get_tree_by_id(handle);
	//if (tree == g_tree_index - 1)return 0;
	for (int i = 0; i < g_tree_index-1; i++){
		if (trees[i]==tree)
		exchange(&trees[i],&trees[i+1]);
	}
	return 1;
}
int do_Click(int w, int h){
	int tree = get_tree_by_xy(w,h);
	if (tree < 0)return 0;
	for (int i = 0; i < g_tree_index-1 ; i++){
		if (trees[i] == tree)
			exchange(&trees[i], &trees[i + 1]);
	}
	return 1;
}
////////////////////////////////////////////////////////////////////////////////////////////////

void InitWinManager(char bgcolor)
{
	// To do
	g_bgc = bgcolor;
	clean();
	g_tree_index = 0;
	g_index = 0;
	
	//Do not remove
	DisplayUpdate(DisBuf);
}

int CreateWindow(int parent, int x, int y, int width, int height, char bgcolor)
{
	// To do
	int handle = do_CreateWindow(parent,x,y,width,height,bgcolor);

	show();
	
	//Do not remove
	DisplayUpdate(DisBuf);
	
	return handle;
}

void DestroyWindow (int handle)
{
	// To do
	int need = do_DestroyWindow(handle);

	if (need)show();
	
	//Do not remove
	DisplayUpdate(DisBuf);
}

void FillRect (int handle, int x, int y, int width, int height, char color)
{
	// To do
	int need = do_FillRect(handle,x,y,width,height,color);

	if (need)show();
	
	//Do not remove
	DisplayUpdate(DisBuf);
}

void ActiveWindow(int handle)
{
	// To do
	int need = do_ActiveWindow(handle);

	if (need)
		show();
	
	//Do not remove
	DisplayUpdate(DisBuf);
}

void Click(int x, int y)
{
	// To do
	int need = do_Click(x, y);
	
	if (need)
		show();
	//Do not remove
	DisplayUpdate(DisBuf);
}