const int MAX_CMD = 4096;
const int MAX_STR = MAX_CMD * 2 + 1;

extern bool save(int cmd, int line);

void run(const char* str)
{
	// TO DO
}
