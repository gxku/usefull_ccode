public class UserSolution {
	
	private Cpu cpu;
	
	UserSolution(Cpu c) {
		cpu = c;
	}

    public void run(String str) {
		// TO DO
    }    
}
