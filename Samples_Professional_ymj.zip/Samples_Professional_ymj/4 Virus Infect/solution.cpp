#define CMD_ADD			1
#define CMD_MOVE		2
#define CMD_INFECT		3
#define CMD_RECOVER		4
#define CMD_REMOVE		5

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

void init()
{

}

int add(int id, int pid, int fileSize)
{

	return -1;
}

int move(int id, int pid)
{

	return -1;
}

int infect(int id)
{

	return -1;
}

int recover(int id)
{

	return -1;
}

int remove(int id)
{

	return -1;
}