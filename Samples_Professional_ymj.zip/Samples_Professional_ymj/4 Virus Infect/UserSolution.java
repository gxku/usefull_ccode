
class UserSolution {
	
	public void init() {
	
	}
	
	public int add(int id, int pid, int fileSize) {
		
		return -1;
	}

	public int move(int id, int pid) {
		
		return -1;
	}

	public int infect(int id) {
		
		return -1;
	}

	public int recover(int id) {
		
		return -1;
	}

	public int remove(int id) {
		
		return -1;
	}
	
}
