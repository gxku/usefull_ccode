public class UserSolution {

	void Init(int N, int[] size, char[] data, int M, Solution.Huffman[] code) {

	}

	void Goto(int frame) {

	}

	int Tick(char[] screen) {

		return 0;
	}
}
