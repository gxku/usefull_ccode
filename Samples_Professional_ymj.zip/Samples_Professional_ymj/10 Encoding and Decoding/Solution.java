import java.util.Scanner;

public class Solution {
	static class Huffman {
		int symbol;
		int codeword;
		int codewordLength;
	}

	private static final int GOTO = 0;
	private static final int TICK = 1;

	public static final int MAX_N = 20000;
	public static final int MAX_M = 128;
	public static final int MAX_BLOCKCOUNT = 1250;
	public static final int MAX_DATALENGTH = 5120000;
	public static final int FRAMESIZE = 256;

	private static int[] size = new int[MAX_BLOCKCOUNT];
	private static char[] data = new char[MAX_DATALENGTH];
	private static Huffman[] code = new Huffman[MAX_M];

	static {
		for (int i = 0; i < MAX_M; i++) {
			code[i] = new Huffman();
		}
	}

	private static int N;
	private static int M;
	private static int point;
	private static int expected;

	private static final int THRESHOLD = 0x07FFFFFF;

	private static Scanner sc;

	public static void main(String[] args) throws Exception {
		System.setIn(new java.io.FileInputStream("sample_input.txt"));
		sc = new Scanner(System.in);

		UserSolution solution = new UserSolution();

		int T = sc.nextInt();
		int totalScore = 0;
		for (int tc = 1; tc <= T; tc++) {
			loadData(size, data, code);

			solution.Init(N, size, data, M, code);
			run(solution);
			System.out.println("#" + tc + " " + point);

			if (point == expected) {
				totalScore++;
			}
		}
		System.out.println("total score = " + totalScore * 100 / T);
		sc.close();
	}

	private static void loadData(int[] sizeArray, char[] dataArray, Huffman[] code) {
		N = sc.nextInt();
		M = sc.nextInt();

		for (int i = 0; i < M; i++) {
			code[i].symbol = sc.nextInt();
			code[i].codeword = sc.nextInt();
			code[i].codewordLength = sc.nextInt();
		}

		int count;
		count = sc.nextInt();
		for (int i = 0; i < count; i++) {
			sizeArray[i] = sc.nextInt();
		}

		count = sc.nextInt();
		for (int i = 0; i < count; i++) {
			dataArray[i] = (char) sc.nextInt();
		}

		point = 0;
	}

	private static void run(UserSolution solution) {
		int lineN = 0;
		int t = 0;
		int frame;
		int hash;
		int command;
		int resultHash;
		char[] screen = new char[FRAMESIZE];

		lineN = sc.nextInt();
		expected = sc.nextInt();
		for (int line = 0; line < lineN; line++) {
			command = sc.nextInt();
			switch (command) {
			case GOTO:
				frame = sc.nextInt();
				solution.Goto(frame);
				break;
			case TICK:
				hash = sc.nextInt();
				frame = sc.nextInt();
				t = solution.Tick(screen);
				resultHash = calcHash(screen, FRAMESIZE);
				if (t == frame && resultHash == hash) {
					point++;
				}
				break;
			default:
				break;
			}
		}
	}

	private static int calcHash(char[] screen, int len) {
		int ret = 0;
		int p = 1;
		for (int x = 0; x < len; x++) {
			ret += screen[x] * p++;
			ret &= THRESHOLD;
		}
		return ret;
	}
}