#define MAX_N				20000
#define MAX_M				128
#define MAX_BLOCKCOUNT		1250
#define MAX_DATALENGTH		5120000
#define FRAMESIZE			256

struct huffman
{
	int symbol, codeword, codewordLength;
};

void Init(int N, int *size, unsigned char *data, int M, struct huffman *code)
{

}

void Goto(int frame)
{

}

int Tick(unsigned char *screen)
{
	return 0;
}
