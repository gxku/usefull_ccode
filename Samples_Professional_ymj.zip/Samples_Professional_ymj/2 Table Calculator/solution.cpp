#define WIDTH	26
#define HEIGHT	99
#define LENGTH	200
const int THRESHOLD = 100000007;
char Table[HEIGHT][WIDTH][LENGTH];

///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////

void initTable(){
    // TO DO	
	
}

bool updateCell(int row, int col, char equation[LENGTH], int value[HEIGHT][WIDTH])
{    
    // TO DO    	
	
	return true; // Need to be changed
}
