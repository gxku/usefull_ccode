package tablecalculator;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

class Algorithm{
	public static final int WIDTH = 26;
	public static final int HEIGHT = 99;
	public static final int LENGTH = 200;

	public static final int THRESHOLD = 100000007;

	public static int value[][] = new int[HEIGHT][WIDTH];
	
	public static Scanner sc; 

	public static int main_init()
	{
		for(int i = 0; i < HEIGHT; ++i)
		{
			for(int j = 0; j < WIDTH; ++j)
			{
				value[i][j] = 0;
			}
		}
		int cmd = sc.nextInt();
		return cmd;
	}

	public static int calcChecksum(int value[][], boolean ret)
	{
		int sum = 0;
		for(int i = 0; i < HEIGHT; ++i)
		{
			for(int j = 0; j < WIDTH; ++j)
			{			
				sum += value[i][j];
				sum %= THRESHOLD;
			}
		}
		if(!ret) ++sum;
		sum %= THRESHOLD;
		if(sum < 0) sum += THRESHOLD;
		return sum;
	}

	public static void main() throws FileNotFoundException
	{
		sc = new Scanner(new File("sample_input.txt"));
		
		int T = sc.nextInt();
	    int totalScore = 0;
		for(int tc = 1; tc <= T; ++tc)
		{
			Solution.initTable();
			int row, col;
			String input = new String();
			int checksumIn = 0;
			int cmd = main_init();        
			int score = 0;
			
			for(int i = 0; i < cmd; ++i)
			{
				row = sc.nextInt();
				col = sc.nextInt();
				input = sc.next();
				checksumIn = sc.nextInt();
				if(checksumIn < 0) checksumIn += THRESHOLD;
				boolean ret = Solution.updateCell(row, col, input, value);
				int checksum = calcChecksum(value, ret);			
				if(checksumIn == checksum) ++score;
			}	
			System.out.println("#" + tc + ' ' + score);
			totalScore += score;
		}
		System.out.println("TotalScore = " + totalScore);
	}
}

