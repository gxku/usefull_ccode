class UserSolution {
	
	public void Run(char button, char display[]) {
		
	}
}