import java.util.Scanner;

class Solution {

	private static Scanner sc;

	private static char button;
	private static char number[] = new char[32 + 1];
	private static char compare[] = new char[32 + 1];
	private static char display[] = new char[32 + 1];

	private static UserSolution user = new UserSolution();

	public static void main(String[] args) throws Exception {

			   // System.setIn(new java.io.FileInputStream("res/sample_input.txt"));
		sc = new Scanner(System.in);

		int testcase = sc.nextInt();

		for (int t = 1; t <= testcase; ++t) {
			int cnt;
			cnt = sc.nextInt();
			int ret = 0;
			for (int i = 0; i < cnt; ++i) {

				button = sc.next().charAt(0);
				String nStr = sc.next();

				int len = nStr.length();
				for (int j = 0; j < len; j++) {
					number[j] = nStr.charAt(j);
				}
				number[len] = '\0';

				if (button == 'N') {
					for (int j = 0; j < len; ++j) {
						compare[j] = number[j];
						compare[j + 1] = 0;
						user.Run(number[j], display);
						if (mystrcmp(display, compare) == 0)
							++ret;
						   }
					}
					   else {
					user.Run(button, display);
					if (mystrcmp(display, number) == 0)
						++ret;
				}
			}
			System.out.println("#" + t + " " + ret);
		}
		sc.close();
	}

	private static int mystrcmp(char[] s1, char[] s2) {
		for (int i = 0; i <= 32; i++) {
			if (s1[i] != s2[i])
				break;

			if (s1[i] == '\0')
				return 0;
		}
		return 1;
	}
}