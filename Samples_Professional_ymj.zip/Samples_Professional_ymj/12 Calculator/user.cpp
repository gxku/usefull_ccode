void Run(char button, char display[32 + 1])
{

}