#define BLOCK_SIZE          2
#define ROTATE_90           1
#define ROTATE_180          2
#define ROTATE_270          3
#define ROTATE_360          4
#define BOARD_MAX_WIDTH     10

#define R 0
#define D 1
#define L 2
#define U 3

#define CAMRM 2
#define VISTED  3
#define MODIFY 4
#define NEXT_BOMB 5

int game_bd_values[600][BOARD_MAX_WIDTH];
int game_bd_status[600][BOARD_MAX_WIDTH];
int game_bd_check_status[600][BOARD_MAX_WIDTH];
int game_bd_height[BOARD_MAX_WIDTH];
struct B
{
	int a_j;
	int pos;
	int a_value;
	int b_value;
}blk;

struct Q{
	int i;
	int j;
}modify_queue[600], ok_queue[600], check_queue[600];
int modify_queue_cnt;
int check_queue_cnt;
int ok_queue_cnt ;
int g_width;

int g_hinder_cnt;
int g_hinder_life;
///////////////////////////////////////////////////
int get_max_h(){
	int max = 0;
	for (int i = 0; i < g_width; i++){
		max = game_bd_height[i]>max ? game_bd_height[i]:max;
	}
	return max;
}

void in_modify_queue(int i, int j){
	int index = modify_queue_cnt++;
	modify_queue[index].i = i;
	modify_queue[index].j = j;
}

void down_cric(int j, int v){
	int h = game_bd_height[j]++;
	game_bd_status[h][j] = 0;
	game_bd_values[h][j] = v;
	if (v < 10){
		in_modify_queue(h,j);
	}
}

void down(){
	if (g_hinder_cnt != 0){
		for (int j = 0; j < g_hinder_cnt; j++){
			down_cric(j, 10 + g_hinder_life);
		}
		g_hinder_cnt = 0;
		return;
	}


	switch (blk.pos)
	{
		case  R:
			down_cric(blk.a_j, blk.a_value);
			down_cric(blk.a_j + 1, blk.b_value);
			break;
		case  D:
			down_cric(blk.a_j, blk.b_value);
			down_cric(blk.a_j, blk.a_value);
			break;
		case  L:
			down_cric(blk.a_j, blk.a_value);
			down_cric(blk.a_j-1, blk.b_value);
			break;
		case  U:
			down_cric(blk.a_j, blk.a_value);
			down_cric(blk.a_j, blk.b_value);

			break;
	default:
		break;
	}

}



void in_check_queue(int i, int j){
	int index = check_queue_cnt++;
	check_queue[index].i = i;
	check_queue[index].j = j;
	game_bd_check_status[i][j] = VISTED;
}

void in_ok_queue(int i, int j){
	int index = ok_queue_cnt++;
	ok_queue[index].i = i;
	ok_queue[index].j = j;
}

void bfs_check(int o_i,int o_j){
	ok_queue_cnt = 0;
	check_queue_cnt = 0;
	int head = 0;
	int i, j;
	int value;
	if (game_bd_status[o_i][o_j] == CAMRM)return;

	for (int n = 0; n < g_width; n++){
		for (int m = 0; m < game_bd_height[n]; m++){
			game_bd_check_status[m][n] = 0;
		}
	}
	in_check_queue(o_i, o_j);
	in_ok_queue(o_i, o_j);
	value = game_bd_values[o_i][o_j];
	while (head != check_queue_cnt){
		/////
		i = check_queue[head].i;
		j = check_queue[head].j;
		
		i--;
		if (i >= 0 && i < game_bd_height[j] && j >= 0 && j < g_width){
			if (game_bd_check_status[i][j] != VISTED&&value == game_bd_values[i][j]){
				in_check_queue(i, j);
				in_ok_queue(i, j);
			}
		}
		/////
		i = check_queue[head].i;
		j = check_queue[head].j;
		j--;
		if (i >= 0 && i < game_bd_height[j] && j >= 0 && j < g_width){
			if (game_bd_check_status[i][j] != VISTED&&value == game_bd_values[i][j]){
				in_check_queue(i, j);
				in_ok_queue(i, j);
			}
		}
		/////
		i = check_queue[head].i;
		j = check_queue[head].j;
		i++;
		if (i >= 0 && i < game_bd_height[j] && j >= 0 && j < g_width){
			if (game_bd_check_status[i][j] != VISTED&&value == game_bd_values[i][j]){
				in_check_queue(i, j);
				in_ok_queue(i, j);
			}
		}
		/////
		i = check_queue[head].i;
		j = check_queue[head].j;
		j++;
		if (i >= 0 && i < game_bd_height[j] && j >= 0 && j < g_width){
			if (game_bd_check_status[i][j] != VISTED&&value == game_bd_values[i][j]){
				in_check_queue(i, j);
				in_ok_queue(i, j);
			}
		}
		head++;
	}

	if (ok_queue_cnt >= 4){
		for (int n = 0; n < ok_queue_cnt; n++){
			i = ok_queue[n].i;
			j = ok_queue[n].j;
			game_bd_status[i][j] = CAMRM;
			i--;
			if (i >= 0 && i < game_bd_height[j] && j >= 0 && j < g_width){
				if (game_bd_values[i][j]>10){
					game_bd_status[i][j] = NEXT_BOMB;
				}
			}

			i = ok_queue[n].i;
			j = ok_queue[n].j;
			i++;
			if (i >= 0 && i < game_bd_height[j] && j >= 0 && j < g_width){
				if (game_bd_values[i][j]>10){
					game_bd_status[i][j] = NEXT_BOMB;
				}
			}

			i = ok_queue[n].i;
			j = ok_queue[n].j;
			j--;
			if (i >= 0 && i < game_bd_height[j] && j >= 0 && j < g_width){
				if (game_bd_values[i][j]>10){
					game_bd_status[i][j] = NEXT_BOMB;
				}
			}

			i = ok_queue[n].i;
			j = ok_queue[n].j;
			j++;
			if (i >= 0 && i < game_bd_height[j] && j >= 0 && j < g_width){
				if (game_bd_values[i][j]>10){
					game_bd_status[i][j] = NEXT_BOMB;
				}
			}
		}
	}

}

void check(){
	int head = 0;
	int i, j;
	while (head != modify_queue_cnt){
		i = modify_queue[head].i;
		j = modify_queue[head].j;

		bfs_check(i, j);
		head++;
	}

}

void disappear(){
	int p,mvd;
	for (int j = 0; j < g_width; j++){
		p = 0;
		mvd = 0;
		for (int n = 0; n < game_bd_height[j]; n++){
			if (game_bd_status[n][j] == NEXT_BOMB){
				if (--game_bd_values[n][j] == 10){
					game_bd_status[n][j] = CAMRM;
				}
				else{
					game_bd_status[n][j] = 0;
				}
			}
			if (game_bd_status[n][j] != CAMRM){
				game_bd_values[p][j] = game_bd_values[n][j];
				game_bd_status[p][j] = game_bd_status[n][j];
				if (mvd){
					in_modify_queue(p,j);
				}
				p++;
			}
			else{
				mvd = 1;
			}
		}
		game_bd_height[j] = p;
		for (int n = p; n < game_bd_height[j]; n++){
			game_bd_values[n][j]=0;
			game_bd_status[n][j]=0;
		}
	}
}
///////////////////////////////////////////////////
void init(int width) {
	g_width = width;
	modify_queue_cnt = 0;
	for (int i = 0; i < g_width; i++){
		game_bd_height[i] = 0;
	}
	for (int i = 0; i < 600; i++){
		for (int j = 0; j < BOARD_MAX_WIDTH; j++){
			game_bd_values[i][j] = 0;
			game_bd_status[i][j] = 0;
		}
	}
g_hinder_cnt=0;
g_hinder_life=0;
}

void newBlock(int block[BLOCK_SIZE]) {
	blk.a_j = 1;
	blk.pos = R;
	blk.a_value = block[0];
	blk.b_value = block[1];
}

void rotate(int angle) {  // 1: ROTATE_90, 2: ROTATE_180, 3: ROTATE_270, 4: ROTATE_360

	
	blk.pos = (blk.pos + angle) % 4;
	if (blk.a_j == 0){
		if (blk.pos == L){
			blk.a_j++;
		}
	}
	else if (blk.a_j == g_width - 1){
		if (blk.pos == R){
			blk.a_j--;
		}
	}

}

void move(int distance) {
	blk.a_j += distance; 
	if(blk.pos==U||blk.pos==D){
		if (blk.a_j < 0){
			blk.a_j = 0;
		}
		else if (blk.a_j > g_width - 1){
			blk.a_j = g_width - 1;
		}
	}
	else if (blk.pos == L){
		if (blk.a_j < 1){
			blk.a_j = 1;
		}
		else if (blk.a_j > g_width - 1){
			blk.a_j = g_width - 1;
		}
	}
	else{
		if (blk.a_j < 0){
			blk.a_j = 0;
		}
		else if (blk.a_j > g_width - 2){
			blk.a_j = g_width - 2;
		}
	}
}

void hinder(int count, int life) {
	g_hinder_cnt = count;
	g_hinder_life = life;

}

int land() {
	down();
	while (modify_queue_cnt != 0){
		check();
		modify_queue_cnt = 0;
		disappear();
	}
	return get_max_h();
}

