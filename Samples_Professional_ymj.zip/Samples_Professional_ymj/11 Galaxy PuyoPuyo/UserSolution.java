
public class UserSolution {
	private static final int BLOCK_SIZE = 2;
    private static final int ROTATE_90 = 1;
    private static final int ROTATE_180 = 2;
    private static final int ROTATE_270 = 3;
    private static final int ROTATE_360 = 4;
    
    
    public void init(int width) {
    	
    }
    
    public void newBlock(int block[]) {
    	
    }

    public void rotate(int angle) {  
    	
    }
    
    public void move(int distance) {
   
    }

    public void hinder(int count, int life) {
    	
    }
    
    public int land() {
        return -1;
    }
 
}
